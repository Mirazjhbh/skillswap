/**
 * SkillSwap Database Layer
 * Powered by Node.js built-in node:sqlite (DatabaseSync) and native crypto.
 */

const { DatabaseSync } = require('node:sqlite');
const path = require('node:path');
const crypto = require('node:crypto');

const DB_PATH = path.join(__dirname, 'skillswap.db');
const db = new DatabaseSync(DB_PATH);

// Configure SQLite pragmas
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

// Initialize Tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL COLLATE NOCASE,
    password_hash TEXT,
    salt TEXT,
    full_name TEXT NOT NULL,
    role_title TEXT DEFAULT 'Skill Swapper',
    avatar_url TEXT DEFAULT '',
    skills_teach TEXT DEFAULT '',
    skills_learn TEXT DEFAULT '',
    project_interest TEXT DEFAULT '',
    cadence TEXT DEFAULT 'Weekly Google Meet Sessions',
    bio TEXT DEFAULT '',
    google_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS proposals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sender_id INTEGER NOT NULL,
    receiver_id INTEGER NOT NULL,
    learn_skill TEXT NOT NULL,
    teach_skill TEXT NOT NULL,
    message TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user1_id INTEGER NOT NULL,
    user2_id INTEGER NOT NULL,
    proposal_id INTEGER,
    meet_url TEXT DEFAULT 'https://meet.google.com/qmv-ytpk-zbw',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(user1_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(user2_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(proposal_id) REFERENCES proposals(id) ON DELETE SET NULL,
    UNIQUE(user1_id, user2_id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER NOT NULL,
    sender_id INTEGER NOT NULL,
    text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reviewer_id INTEGER NOT NULL,
    reviewee_id INTEGER NOT NULL,
    rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
    review_text TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(reviewer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(reviewee_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    conversation_id INTEGER,
    title TEXT NOT NULL,
    host_id INTEGER NOT NULL,
    participant_id INTEGER NOT NULL,
    scheduled_time TEXT,
    meet_url TEXT DEFAULT 'https://meet.google.com/qmv-ytpk-zbw',
    status TEXT DEFAULT 'scheduled',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(conversation_id) REFERENCES conversations(id) ON DELETE SET NULL,
    FOREIGN KEY(host_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY(participant_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

// -----------------------------------------------------------------
// Password & Token Security Utilities
// -----------------------------------------------------------------

const TOKEN_SECRET = 'skillswap-secret-token-key-2026-dynamic-app';

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return { hash, salt };
}

function verifyPassword(password, hash, salt) {
  if (!hash || !salt) return false;
  try {
    const testHash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(testHash, 'hex'));
  } catch (e) {
    return false;
  }
}

function generateSessionToken(user) {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const payload = Buffer.from(JSON.stringify({
    userId: user.id,
    email: user.email,
    name: user.full_name,
    exp: Date.now() + 1000 * 60 * 60 * 24 * 7 // 7 days
  })).toString('base64url');

  const signature = crypto.createHmac('sha256', TOKEN_SECRET)
    .update(`${header}.${payload}`)
    .digest('base64url');

  return `${header}.${payload}.${signature}`;
}

function verifySessionToken(token) {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;

  const [header, payload, signature] = parts;
  const expectedSig = crypto.createHmac('sha256', TOKEN_SECRET)
    .update(`${header}.${payload}`)
    .digest('base64url');

  if (signature !== expectedSig) return null;

  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    if (data.exp && data.exp < Date.now()) return null;
    return data;
  } catch (e) {
    return null;
  }
}

// -----------------------------------------------------------------
// Database Operations Helper Methods
// -----------------------------------------------------------------

// User Queries
function createUser({ email, password, full_name, role_title, avatar_url, skills_teach, skills_learn, project_interest, cadence, google_id }) {
  let hash = null;
  let salt = null;
  if (password) {
    const hashed = hashPassword(password);
    hash = hashed.hash;
    salt = hashed.salt;
  }

  const stmt = db.prepare(`
    INSERT INTO users (email, password_hash, salt, full_name, role_title, avatar_url, skills_teach, skills_learn, project_interest, cadence, google_id)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const result = stmt.run(
    email.toLowerCase().trim(),
    hash,
    salt,
    full_name.trim(),
    role_title || 'Skill Swapper',
    avatar_url || '',
    skills_teach || '',
    skills_learn || '',
    project_interest || '',
    cadence || 'Weekly Google Meet Sessions',
    google_id || null
  );

  return getUserById(result.lastInsertRowid);
}

function getUserByEmail(email) {
  if (!email) return null;
  const stmt = db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE');
  return stmt.get(email.toLowerCase().trim());
}

function getUserById(id) {
  if (!id) return null;
  const stmt = db.prepare('SELECT * FROM users WHERE id = ?');
  const user = stmt.get(id);
  if (!user) return null;
  
  // Calculate average rating and review count dynamically from DB
  const ratingStmt = db.prepare('SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM reviews WHERE reviewee_id = ?');
  const ratingData = ratingStmt.get(id);

  return {
    ...user,
    avg_rating: ratingData && ratingData.avg_rating ? Number(Number(ratingData.avg_rating).toFixed(1)) : null,
    review_count: ratingData ? ratingData.review_count : 0
  };
}

function getUserByGoogleId(googleId) {
  if (!googleId) return null;
  const stmt = db.prepare('SELECT * FROM users WHERE google_id = ?');
  return stmt.get(googleId);
}

function updateUserProfile(id, updates) {
  const fields = [];
  const values = [];

  const allowedFields = ['full_name', 'role_title', 'avatar_url', 'skills_teach', 'skills_learn', 'project_interest', 'cadence', 'bio'];
  for (const key of allowedFields) {
    if (updates[key] !== undefined) {
      fields.push(`${key} = ?`);
      values.push(updates[key]);
    }
  }

  if (fields.length === 0) return getUserById(id);

  fields.push('updated_at = CURRENT_TIMESTAMP');
  values.push(id);

  const query = `UPDATE users SET ${fields.join(', ')} WHERE id = ?`;
  db.prepare(query).run(...values);

  return getUserById(id);
}

function getAllUsers(currentUserId = null) {
  const stmt = db.prepare('SELECT id, full_name, email, role_title, avatar_url, skills_teach, skills_learn, project_interest, cadence, bio, created_at FROM users ORDER BY id DESC');
  const users = stmt.all();

  return users.map(user => {
    const ratingStmt = db.prepare('SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM reviews WHERE reviewee_id = ?');
    const ratingData = ratingStmt.get(user.id);
    return {
      ...user,
      avg_rating: ratingData && ratingData.avg_rating ? Number(Number(ratingData.avg_rating).toFixed(1)) : null,
      review_count: ratingData ? ratingData.review_count : 0,
      is_current_user: currentUserId ? user.id === currentUserId : false
    };
  });
}

// Proposals Queries
function createProposal({ sender_id, receiver_id, learn_skill, teach_skill, message }) {
  const stmt = db.prepare(`
    INSERT INTO proposals (sender_id, receiver_id, learn_skill, teach_skill, message)
    VALUES (?, ?, ?, ?, ?)
  `);
  const result = stmt.run(sender_id, receiver_id, learn_skill, teach_skill, message || '');
  return getProposalById(result.lastInsertRowid);
}

function getProposalById(id) {
  const stmt = db.prepare(`
    SELECT p.*,
      s.full_name as sender_name, s.email as sender_email, s.avatar_url as sender_avatar,
      r.full_name as receiver_name, r.email as receiver_email, r.avatar_url as receiver_avatar
    FROM proposals p
    JOIN users s ON p.sender_id = s.id
    JOIN users r ON p.receiver_id = r.id
    WHERE p.id = ?
  `);
  return stmt.get(id);
}

function getUserProposals(userId) {
  const stmt = db.prepare(`
    SELECT p.*,
      s.full_name as sender_name, s.email as sender_email, s.avatar_url as sender_avatar,
      r.full_name as receiver_name, r.email as receiver_email, r.avatar_url as receiver_avatar
    FROM proposals p
    JOIN users s ON p.sender_id = s.id
    JOIN users r ON p.receiver_id = r.id
    WHERE p.sender_id = ? OR p.receiver_id = ?
    ORDER BY p.id DESC
  `);
  return stmt.all(userId, userId);
}

function updateProposalStatus(id, status) {
  db.prepare('UPDATE proposals SET status = ? WHERE id = ?').run(status, id);
  const proposal = getProposalById(id);

  if (status === 'accepted') {
    // Automatically create or get conversation
    let conv = getOrCreateConversation(proposal.sender_id, proposal.receiver_id, proposal.id);
    
    // Automatically create an initial session
    createSession({
      conversation_id: conv.id,
      title: `Skill Exchange: ${proposal.learn_skill} ⇄ ${proposal.teach_skill}`,
      host_id: proposal.sender_id,
      participant_id: proposal.receiver_id,
      scheduled_time: 'Next Friday · 6:30 PM (BST)',
      meet_url: conv.meet_url
    });

    // Add initial greeting message
    addMessage({
      conversation_id: conv.id,
      sender_id: proposal.sender_id,
      text: `Hi ${proposal.receiver_name.split(' ')[0]}! Excited to connect for our exchange: ${proposal.learn_skill} ⇄ ${proposal.teach_skill}. ${proposal.message ? `\n"${proposal.message}"` : ''}`
    });
  }

  return proposal;
}

// Conversation Queries
function getOrCreateConversation(userIdA, userIdB, proposalId = null) {
  const u1 = Math.min(userIdA, userIdB);
  const u2 = Math.max(userIdA, userIdB);

  let conv = db.prepare('SELECT * FROM conversations WHERE user1_id = ? AND user2_id = ?').get(u1, u2);
  if (!conv) {
    const randomMeetCode = `${Math.random().toString(36).substring(2, 5)}-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 5)}`;
    const meetUrl = `https://meet.google.com/${randomMeetCode}`;

    const stmt = db.prepare(`
      INSERT INTO conversations (user1_id, user2_id, proposal_id, meet_url)
      VALUES (?, ?, ?, ?)
    `);
    const result = stmt.run(u1, u2, proposalId, meetUrl);
    conv = db.prepare('SELECT * FROM conversations WHERE id = ?').get(result.lastInsertRowid);
  }
  return conv;
}

function getUserConversations(userId) {
  const stmt = db.prepare(`
    SELECT c.*,
      CASE WHEN c.user1_id = ? THEN c.user2_id ELSE c.user1_id END as other_user_id
    FROM conversations c
    WHERE c.user1_id = ? OR c.user2_id = ?
    ORDER BY c.updated_at DESC
  `);
  const convs = stmt.all(userId, userId, userId);

  return convs.map(conv => {
    const otherUser = getUserById(conv.other_user_id);
    const lastMsg = db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY id DESC LIMIT 1').get(conv.id);
    return {
      ...conv,
      other_user: otherUser,
      last_message: lastMsg || null
    };
  });
}

function updateConversationMeet(convId, meetUrl) {
  db.prepare('UPDATE conversations SET meet_url = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(meetUrl, convId);
  return db.prepare('SELECT * FROM conversations WHERE id = ?').get(convId);
}

// Message Queries
function addMessage({ conversation_id, sender_id, text }) {
  const stmt = db.prepare(`
    INSERT INTO messages (conversation_id, sender_id, text)
    VALUES (?, ?, ?)
  `);
  const result = stmt.run(conversation_id, sender_id, text);
  db.prepare('UPDATE conversations SET updated_at = CURRENT_TIMESTAMP WHERE id = ?').run(conversation_id);
  
  const msg = db.prepare(`
    SELECT m.*, u.full_name as sender_name, u.avatar_url as sender_avatar
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.id = ?
  `).get(result.lastInsertRowid);

  return msg;
}

function getConversationMessages(conversationId) {
  const stmt = db.prepare(`
    SELECT m.*, u.full_name as sender_name, u.avatar_url as sender_avatar
    FROM messages m
    JOIN users u ON m.sender_id = u.id
    WHERE m.conversation_id = ?
    ORDER BY m.id ASC
  `);
  return stmt.all(conversationId);
}

// Review Queries
function addReview({ reviewer_id, reviewee_id, rating, review_text }) {
  const stmt = db.prepare(`
    INSERT INTO reviews (reviewer_id, reviewee_id, rating, review_text)
    VALUES (?, ?, ?, ?)
  `);
  const result = stmt.run(reviewer_id, reviewee_id, rating, review_text);
  return getReviewById(result.lastInsertRowid);
}

function getReviewById(id) {
  const stmt = db.prepare(`
    SELECT r.*,
      reviewer.full_name as reviewer_name, reviewer.avatar_url as reviewer_avatar,
      reviewee.full_name as reviewee_name, reviewee.avatar_url as reviewee_avatar
    FROM reviews r
    JOIN users reviewer ON r.reviewer_id = reviewer.id
    JOIN users reviewee ON r.reviewee_id = reviewee.id
    WHERE r.id = ?
  `);
  return stmt.get(id);
}

function getAllReviews() {
  const stmt = db.prepare(`
    SELECT r.*,
      reviewer.full_name as reviewer_name, reviewer.avatar_url as reviewer_avatar, reviewer.role_title as reviewer_role,
      reviewee.full_name as reviewee_name, reviewee.avatar_url as reviewee_avatar, reviewee.role_title as reviewee_role
    FROM reviews r
    JOIN users reviewer ON r.reviewer_id = reviewer.id
    JOIN users reviewee ON r.reviewee_id = reviewee.id
    ORDER BY r.id DESC
  `);
  return stmt.all();
}

// Sessions Queries
function createSession({ conversation_id, title, host_id, participant_id, scheduled_time, meet_url }) {
  const stmt = db.prepare(`
    INSERT INTO sessions (conversation_id, title, host_id, participant_id, scheduled_time, meet_url)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const result = stmt.run(conversation_id || null, title, host_id, participant_id, scheduled_time, meet_url || 'https://meet.google.com/qmv-ytpk-zbw');
  return db.prepare('SELECT * FROM sessions WHERE id = ?').get(result.lastInsertRowid);
}

function getUserSessions(userId) {
  const stmt = db.prepare(`
    SELECT s.*,
      host.full_name as host_name, host.avatar_url as host_avatar,
      part.full_name as participant_name, part.avatar_url as participant_avatar
    FROM sessions s
    JOIN users host ON s.host_id = host.id
    JOIN users part ON s.participant_id = part.id
    WHERE s.host_id = ? OR s.participant_id = ?
    ORDER BY s.id DESC
  `);
  return stmt.all(userId, userId);
}

// Platform Stats
function getPlatformStats() {
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const exchangeCount = db.prepare('SELECT COUNT(*) as count FROM conversations').get().count;
  const reviewCount = db.prepare('SELECT COUNT(*) as count FROM reviews').get().count;
  const avgRatingData = db.prepare('SELECT AVG(rating) as avg FROM reviews').get();

  return {
    total_users: userCount,
    total_exchanges: exchangeCount,
    total_reviews: reviewCount,
    avg_community_rating: avgRatingData && avgRatingData.avg ? Number(Number(avgRatingData.avg).toFixed(1)) : null
  };
}

module.exports = {
  db,
  hashPassword,
  verifyPassword,
  generateSessionToken,
  verifySessionToken,
  createUser,
  getUserByEmail,
  getUserById,
  getUserByGoogleId,
  updateUserProfile,
  getAllUsers,
  createProposal,
  getProposalById,
  getUserProposals,
  updateProposalStatus,
  getOrCreateConversation,
  getUserConversations,
  updateConversationMeet,
  addMessage,
  getConversationMessages,
  addReview,
  getReviewById,
  getAllReviews,
  createSession,
  getUserSessions,
  getPlatformStats
};

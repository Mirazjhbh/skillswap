# SkillSwap - Dynamic Peer-to-Peer Knowledge Exchange Platform

SkillSwap is a full-stack peer-to-peer knowledge exchange platform powered by **Node.js** and **SQLite (`node:sqlite`)**. All user authentication, profile data, skills matching, exchange proposals, real-time messaging, Google Meet links, and ratings are **100% dynamic and backed by a real persistent database**.

---

## Key Features

1. **Database-Driven Authentication**:
   - **Sign Up Free**: Registers new users with password hashing (`scrypt`) and creates user profiles in SQLite.
   - **Login**: Validates credentials against DB. Incorrect details return: *“Invalid email or password. Please try again.”*
   - **Start with Google**: Authenticates Google accounts and links/persists them in the database.
   - **Session Security**: High-speed HMAC-SHA256 JWT tokens.

2. **Real Users Only & Dynamic Discovery**:
   - All profiles in the Hero section, Match panel, and Discover grid are populated dynamically from registered database users who have provided skills.
   - Zero hypothetical/fake accounts or fake numbers.
   - Helpful empty states guide new users: *“Add your skills and learning interests to your profile to appear in the SkillSwap community.”*

3. **Intelligent Skill Matching & Exchange Proposals**:
   - Algorithm pairs users whose taught skills align with each other's learning goals.
   - Real-time exchange proposals: send, accept, or decline.
   - Accepting an exchange proposal automatically initializes a dedicated conversation and session.

4. **Messenger-Style Real Chat & Google Meet Integration**:
   - Real persistent messaging between matched skill partners stored in SQLite.
   - Switch between multiple active peer conversations.
   - Share and update Google Meet room URLs directly in the session/chat.
   - Direct 1-click **Join Google Meet** button.

5. **Verified Peer Ratings & Community Reviews**:
   - Dynamic 1–5 star reviews stored in the database.
   - Aggregated real user ratings shown across cards.
   - Interactive rating modal allowing swappers to review their partners.

6. **Orchestrated Living Frontend Experience**:
   - Particle synapse canvas & undulating glowing sinusoidal waves.
   - 3D cursor parallax tilting on hero cards and stage.
   - Interactive animated companion mascot (*Dex*).
   - Real-time auto-updating dynamic calendar widgets.

---

## Quick Start & Running the Server

### 1. Start the Dynamic Server
Run the following command from the `skillswap` directory:

```bash
node server.js
```

The server starts at `http://localhost:3000`.

### 2. Open in Browser
Open your browser and navigate to:
```
http://localhost:3000
```

### 3. Run Automated Test Suites
Run the database and API test suite:

```bash
node test-backend.js
node test-e2e.js
```

---

## File Structure

```text
skillswap/
├── server.js         # Node.js REST API & static file HTTP server
├── database.js       # SQLite database layer (node:sqlite) + scrypt security
├── skillswap.db      # Persistent SQLite database file
├── index.html        # Dynamic frontend template
├── styles.css        # SkillSwap styling, living animations, 3D parallax
├── scripts.js       # Dynamic client controller & API integration
├── test-backend.js   # Unit & database integration tests
├── test-e2e.js       # End-to-end HTTP API test suite
├── package.json      # Project configuration
└── README.md         # Full documentation
```

---

## REST API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/auth/signup` | Register new user account |
| `POST` | `/api/auth/login` | Authenticate existing user |
| `POST` | `/api/auth/google` | Google sign-in / registration |
| `GET` | `/api/auth/me` | Fetch currently authenticated user |
| `POST` | `/api/auth/logout` | End active session |
| `GET` | `/api/users` | List all registered users with skills & ratings |
| `PUT` | `/api/users/profile` | Update current user's profile and skills |
| `GET` | `/api/matches` | Get reciprocal/high-compatibility matches |
| `POST` | `/api/proposals` | Send skill exchange proposal |
| `GET` | `/api/proposals` | List user's received and sent proposals |
| `PUT` | `/api/proposals/:id/status` | Accept or reject proposal |
| `GET` | `/api/conversations` | List active peer conversations |
| `GET` | `/api/conversations/:id/messages` | Get conversation chat history |
| `POST` | `/api/conversations/:id/messages` | Post message to conversation |
| `PUT` | `/api/conversations/:id/meet` | Update Google Meet room link |
| `GET` | `/api/reviews` | Get verified community reviews |
| `POST` | `/api/reviews` | Submit rating & review for partner |
| `GET` | `/api/stats` | Real-time database platform metrics |
| `POST` | `/api/seed` | Seed initial peer demonstration accounts |

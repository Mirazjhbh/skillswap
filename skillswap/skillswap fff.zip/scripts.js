/**
 * SkillSwap Platform - Dynamic Client Core & Living Animations
 * Professional Peer-to-Peer Knowledge Exchange
 * Fully connected to persistent SQLite Backend API
 */

(() => {
  'use strict';

  // -------------------------------------------------------------
  // DOM Elements & Core State
  // -------------------------------------------------------------
  const body = document.body;
  const authGateway = document.querySelector('#auth-gateway');
  const mainApp = document.querySelector('#main-app');
  const toast = document.querySelector('#toast');
  const toastMessage = document.querySelector('#toast-message');
  let toastTimer;

  // Global State
  let currentUser = null;
  let allRegisteredUsers = [];
  let userConversations = [];
  let activeConversationId = null;
  let activeConversationPeer = null;

  // -------------------------------------------------------------
  // Toast Notification System
  // -------------------------------------------------------------
  function showToast(message, icon = '✓') {
    if (!toast || !toastMessage) return;
    toastMessage.textContent = message;
    const iconEl = toast.querySelector('span');
    if (iconEl) iconEl.textContent = icon;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 3500);
  }

  // -------------------------------------------------------------
  // REST API Client
  // -------------------------------------------------------------
  async function api(endpoint, options = {}) {
    const token = localStorage.getItem('skillswap_token');
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...(options.headers || {})
    };

    try {
      const res = await fetch(endpoint, {
        ...options,
        headers
      });
      const data = await res.json();
      return data;
    } catch (err) {
      console.error(`API Error on ${endpoint}:`, err);
      return { ok: false, error: 'Network or server connection error.' };
    }
  }

  // -------------------------------------------------------------
  // 1. SLOW-MOVING BLUE/PURPLE PARTICLES & GLOWING WAVES CANVAS
  // -------------------------------------------------------------
  const canvas = document.querySelector('#synapse-canvas');
  let ctx = canvas ? canvas.getContext('2d') : null;
  let canvasWidth = 0;
  let canvasHeight = 0;
  let animationFrameId;
  let waveTime = 0;

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const PALETTE = [
    { r: 59,  g: 102, b: 255 }, // Royal Blue
    { r: 96,  g: 165, b: 250 }, // Sky/Electric Cyan
    { r: 139, g: 92,  b: 246 }, // Vivid Purple
    { r: 168, g: 85,  b: 247 }, // Neon Violet
    { r: 16,  g: 185, b: 129 }  // Emerald accent
  ];

  class ElegantNode {
    constructor() {
      this.reset();
      this.x = Math.random() * (canvasWidth || window.innerWidth);
      this.y = Math.random() * (canvasHeight || window.innerHeight);
    }

    reset() {
      this.x = Math.random() * (canvasWidth || window.innerWidth);
      this.y = Math.random() * (canvasHeight || window.innerHeight);
      this.vx = (Math.random() - 0.5) * 0.28;
      this.vy = (Math.random() - 0.5) * 0.28;
      this.radius = Math.random() * 2.5 + 1.2;
      this.baseAlpha = Math.random() * 0.45 + 0.22;
      this.alpha = this.baseAlpha;
      this.phase = Math.random() * Math.PI * 2;
      this.color = PALETTE[Math.floor(Math.random() * PALETTE.length)];
    }

    update() {
      this.phase += 0.012;
      this.alpha = this.baseAlpha + Math.sin(this.phase) * 0.16;
      this.x += this.vx;
      this.y += this.vy;

      if (this.x < -30) this.x = canvasWidth + 30;
      if (this.x > canvasWidth + 30) this.x = -30;
      if (this.y < -30) this.y = canvasHeight + 30;
      if (this.y > canvasHeight + 30) this.y = -30;
    }

    draw(isDark) {
      if (!ctx) return;
      const alphaVal = Math.max(0.05, Math.min(1, this.alpha * (isDark ? 0.95 : 0.7)));

      ctx.save();
      const glowGrad = ctx.createRadialGradient(this.x, this.y, 0, this.x, this.y, this.radius * 3.2);
      glowGrad.addColorStop(0, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${alphaVal})`);
      glowGrad.addColorStop(1, `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, 0)`);
      ctx.fillStyle = glowGrad;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius * 3.2, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${this.color.r}, ${this.color.g}, ${this.color.b}, ${Math.min(1, alphaVal * 1.4)})`;
      ctx.fill();
      ctx.restore();
    }
  }

  let nodes = [];
  const NODE_COUNT = 42;

  function initCanvas() {
    if (!canvas || !ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvasWidth = window.innerWidth;
    canvasHeight = window.innerHeight;
    canvas.width = canvasWidth * dpr;
    canvas.height = canvasHeight * dpr;
    ctx.scale(dpr, dpr);

    nodes = [];
    for (let i = 0; i < NODE_COUNT; i++) {
      nodes.push(new ElegantNode());
    }
  }

  function renderGlowingWaves(isDark) {
    if (!ctx) return;
    waveTime += 0.007;
    const baseH = canvasHeight * 0.74;
    const step = 20;

    // Wave 1
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, canvasHeight);
    for (let x = 0; x <= canvasWidth + step; x += step) {
      const y = baseH + Math.sin(x * 0.0022 + waveTime) * 34 + Math.cos(x * 0.0011 + waveTime * 0.7) * 16;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(canvasWidth, canvasHeight);
    ctx.closePath();
    const grad1 = ctx.createLinearGradient(0, baseH - 40, 0, canvasHeight);
    grad1.addColorStop(0, isDark ? 'rgba(59, 102, 255, 0.12)' : 'rgba(59, 102, 255, 0.06)');
    grad1.addColorStop(1, 'rgba(59, 102, 255, 0)');
    ctx.fillStyle = grad1;
    ctx.fill();
    ctx.restore();

    // Wave 2
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(0, canvasHeight);
    for (let x = 0; x <= canvasWidth + step; x += step) {
      const y = (baseH + 30) + Math.sin(x * 0.0018 + waveTime * 0.85 + 1.8) * 38 + Math.sin(x * 0.003 + waveTime * 0.5) * 12;
      ctx.lineTo(x, y);
    }
    ctx.lineTo(canvasWidth, canvasHeight);
    ctx.closePath();
    const grad2 = ctx.createLinearGradient(0, baseH, 0, canvasHeight);
    grad2.addColorStop(0, isDark ? 'rgba(139, 92, 246, 0.10)' : 'rgba(139, 92, 246, 0.05)');
    grad2.addColorStop(1, 'rgba(139, 92, 246, 0)');
    ctx.fillStyle = grad2;
    ctx.fill();
    ctx.restore();

    // Wave 3
    ctx.save();
    ctx.beginPath();
    for (let x = 0; x <= canvasWidth + step; x += step) {
      const y = (baseH - 20) + Math.sin(x * 0.0025 + waveTime * 1.1) * 22;
      if (x === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.strokeStyle = isDark ? 'rgba(96, 165, 250, 0.22)' : 'rgba(59, 102, 255, 0.14)';
    ctx.lineWidth = 1.4;
    ctx.shadowColor = 'rgba(96, 165, 250, 0.45)';
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.restore();
  }

  function renderElegantCanvas() {
    if (!ctx || prefersReducedMotion) return;
    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
    const isDark = body.dataset.theme === 'dark';

    renderGlowingWaves(isDark);

    const maxDist = 135;
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < maxDist) {
          const alpha = (1 - dist / maxDist) * (isDark ? 0.22 : 0.12);
          ctx.beginPath();
          ctx.moveTo(nodes[i].x, nodes[i].y);
          ctx.lineTo(nodes[j].x, nodes[j].y);
          ctx.strokeStyle = `rgba(${nodes[i].color.r}, ${nodes[i].color.g}, ${nodes[i].color.b}, ${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      }
    }

    nodes.forEach(n => {
      n.update();
      n.draw(isDark);
    });

    animationFrameId = requestAnimationFrame(renderElegantCanvas);
  }

  if (canvas) {
    initCanvas();
    window.addEventListener('resize', initCanvas, { passive: true });
    if (!prefersReducedMotion) renderElegantCanvas();
  }

  // -------------------------------------------------------------
  // 2. DYNAMIC REAL-TIME CALENDAR ENGINE
  // -------------------------------------------------------------
  const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const gwCalTitle = document.querySelector('#gw-cal-title');
  const gwCalDays = document.querySelector('#gw-cal-days');
  const gwCalPrev = document.querySelector('#gw-cal-prev');
  const gwCalNext = document.querySelector('#gw-cal-next');

  let weekOffset = 0;

  function renderGatewayWeekCalendar() {
    if (!gwCalTitle || !gwCalDays) return;
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + (weekOffset * 7));

    const todayDate = new Date();
    const todayYear = todayDate.getFullYear();
    const todayMonth = todayDate.getMonth();
    const todayDay = todayDate.getDate();

    gwCalTitle.textContent = `${MONTH_NAMES[targetDate.getMonth()]} ${targetDate.getDate()}, ${targetDate.getFullYear()}`;

    const currentDayOfWeek = targetDate.getDay();
    const startOfWeek = new Date(targetDate);
    startOfWeek.setDate(targetDate.getDate() - currentDayOfWeek);

    gwCalDays.innerHTML = '';
    for (let i = 0; i < 7; i++) {
      const dayDate = new Date(startOfWeek);
      dayDate.setDate(startOfWeek.getDate() + i);

      const isToday = dayDate.getFullYear() === todayYear &&
                      dayDate.getMonth() === todayMonth &&
                      dayDate.getDate() === todayDay;

      const dayCell = document.createElement('span');
      dayCell.className = `cal-day-num${isToday ? ' is-today' : ''}`;
      dayCell.textContent = dayDate.getDate();
      dayCell.setAttribute('title', `${MONTH_NAMES[dayDate.getMonth()]} ${dayDate.getDate()}, ${dayDate.getFullYear()}`);

      dayCell.addEventListener('click', () => {
        gwCalDays.querySelectorAll('.cal-day-num').forEach(d => d.classList.remove('is-today'));
        dayCell.classList.add('is-today');
        gwCalTitle.textContent = `${MONTH_NAMES[dayDate.getMonth()]} ${dayDate.getDate()}, ${dayDate.getFullYear()}`;
        showToast(`Date selected: ${MONTH_NAMES[dayDate.getMonth()]} ${dayDate.getDate()}, ${dayDate.getFullYear()}`, '📅');
      });

      gwCalDays.appendChild(dayCell);
    }
  }

  if (gwCalPrev) gwCalPrev.addEventListener('click', () => { weekOffset--; renderGatewayWeekCalendar(); });
  if (gwCalNext) gwCalNext.addEventListener('click', () => { weekOffset++; renderGatewayWeekCalendar(); });
  renderGatewayWeekCalendar();

  // App Monthly Calendar
  const appCalTitle = document.querySelector('#app-cal-title');
  const appCalDates = document.querySelector('#app-cal-dates');
  const appCalPrev = document.querySelector('#app-cal-prev');
  const appCalNext = document.querySelector('#app-cal-next');

  let appCalMonth = new Date().getMonth();
  let appCalYear = new Date().getFullYear();

  function renderAppMonthCalendar() {
    if (!appCalTitle || !appCalDates) return;
    appCalTitle.textContent = `${MONTH_NAMES[appCalMonth]} ${appCalYear}`;

    const realToday = new Date();
    const realYear = realToday.getFullYear();
    const realMonth = realToday.getMonth();
    const realDay = realToday.getDate();

    const daysInMonth = new Date(appCalYear, appCalMonth + 1, 0).getDate();
    const firstDayIndex = (new Date(appCalYear, appCalMonth, 1).getDay() + 6) % 7;
    const prevMonthDays = new Date(appCalYear, appCalMonth, 0).getDate();

    const cells = [];
    for (let i = firstDayIndex; i > 0; i--) {
      cells.push(`<span class="muted">${prevMonthDays - i + 1}</span>`);
    }
    for (let d = 1; d <= daysInMonth; d++) {
      const isToday = appCalYear === realYear && appCalMonth === realMonth && d === realDay;
      const hasSession = d === 18;
      const hasRequest = d === 24;
      const classes = [];
      if (isToday) classes.push('is-today');
      if (hasSession) classes.push('has-session');
      if (hasRequest) classes.push('has-request');

      const classAttr = classes.length ? ` class="${classes.join(' ')}"` : '';
      cells.push(`<span${classAttr} data-day="${d}">${d}</span>`);
    }
    const trailing = (7 - (cells.length % 7)) % 7;
    for (let d = 1; d <= trailing; d++) {
      cells.push(`<span class="muted">${d}</span>`);
    }
    appCalDates.innerHTML = cells.join('');

    appCalDates.querySelectorAll('span:not(.muted)').forEach((cell) => {
      cell.addEventListener('click', () => {
        appCalDates.querySelectorAll('span').forEach((c) => c.classList.remove('is-today'));
        cell.classList.add('is-today');
        const d = cell.dataset.day;
        showToast(`Viewing schedule for ${MONTH_NAMES[appCalMonth]} ${d}, ${appCalYear}`, '📅');
      });
    });
  }

  if (appCalPrev) {
    appCalPrev.addEventListener('click', () => {
      appCalMonth--;
      if (appCalMonth < 0) { appCalMonth = 11; appCalYear--; }
      renderAppMonthCalendar();
    });
  }
  if (appCalNext) {
    appCalNext.addEventListener('click', () => {
      appCalMonth++;
      if (appCalMonth > 11) { appCalMonth = 0; appCalYear++; }
      renderAppMonthCalendar();
    });
  }
  renderAppMonthCalendar();

  // -------------------------------------------------------------
  // 3. AUTHENTICATION & GATEWAY LOGIC (Connected to Backend DB)
  // -------------------------------------------------------------
  const gatewayAuthForm = document.querySelector('#gateway-auth-form');
  const gwCardTitle = document.querySelector('#gateway-card-title');
  const gwCardSubtitle = document.querySelector('#gateway-card-subtitle');
  const gwSubmitBtn = document.querySelector('#gw-submit-btn');
  const gwModeToggle = document.querySelector('#gw-mode-toggle');
  const gwFooterPrompt = document.querySelector('#gw-footer-prompt');
  const tabLogin = document.querySelector('#tab-login');
  const tabSignup = document.querySelector('#tab-signup');
  const gwNavLoginBtn = document.querySelector('#gw-nav-login-btn');
  const gwNavSignupBtn = document.querySelector('#gw-nav-signup-btn');
  const siteNavLoginBtn = document.querySelector('#site-nav-login-btn');
  const siteNavSignupBtn = document.querySelector('#site-nav-signup-btn');
  const gwTopSignupBtn = document.querySelector('#gw-top-signup-btn');
  const gwTopDemoBtn = document.querySelector('#gw-top-demo-btn');
  const gwDemoBtn = document.querySelector('#gw-demo-btn');
  const passStrengthMeter = document.querySelector('#pass-strength-meter');
  const strengthBarFill = document.querySelector('#strength-bar-fill');
  const strengthVal = document.querySelector('#strength-val');
  const fieldSignupName = document.querySelector('#field-signup-name');
  const fieldSignupSkill = document.querySelector('#field-signup-skill');
  const gwNameInput = document.querySelector('#gw-name-input');
  const gwEmailInput = document.querySelector('#gw-email-input');
  const gwPassInput = document.querySelector('#gw-pass-input');
  const gwPassToggle = document.querySelector('#gw-pass-toggle');
  const gwSkillInput = document.querySelector('#gw-skill-input');
  const gwGoogleBtn = document.querySelector('#gw-google-btn');
  const gwGoogleLabel = document.querySelector('#gw-google-label');
  const gwAuthError = document.querySelector('#gw-auth-error');
  const gwAuthErrorText = document.querySelector('#gw-auth-error-text');

  const userMenuBtn = document.querySelector('#user-menu-btn');
  const userDropdownMenu = document.querySelector('#user-dropdown-menu');
  const appLogoutBtn = document.querySelector('#app-logout-btn');
  const headerUserName = document.querySelector('#header-user-name');
  const dropdownUserName = document.querySelector('#dropdown-user-name');
  const dropdownUserEmail = document.querySelector('#dropdown-user-email');

  let isSignUpMode = false;

  function clearAuthError() {
    if (gwAuthError) gwAuthError.hidden = true;
  }

  function showAuthError(msg) {
    if (gwAuthError && gwAuthErrorText) {
      gwAuthErrorText.textContent = msg;
      gwAuthError.hidden = false;
      gwAuthError.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    } else {
      showToast(msg, '⚠️');
    }
  }

  function setGatewayMode(signup) {
    isSignUpMode = signup;
    clearAuthError();

    if (tabLogin && tabSignup) {
      tabLogin.classList.toggle('active', !signup);
      tabSignup.classList.toggle('active', signup);
      tabLogin.setAttribute('aria-selected', !signup);
      tabSignup.setAttribute('aria-selected', signup);
    }
    if (gwNavLoginBtn && gwNavSignupBtn) {
      gwNavLoginBtn.classList.toggle('active', !signup);
      gwNavSignupBtn.classList.toggle('active', signup);
    }

    if (isSignUpMode) {
      gwCardTitle.textContent = 'Create Your Free Account';
      gwCardSubtitle.textContent = 'Trade skills, build freelance careers, and grow with real peers.';
      gwSubmitBtn.textContent = 'Create Your Free Account →';
      gwFooterPrompt.textContent = 'Already have an account?';
      gwModeToggle.textContent = 'Log in';
      if (fieldSignupName) fieldSignupName.hidden = false;
      if (fieldSignupSkill) fieldSignupSkill.hidden = false;
      if (passStrengthMeter) passStrengthMeter.hidden = false;
      if (gwNameInput) {
        gwNameInput.required = true;
        setTimeout(() => gwNameInput.focus(), 80);
      }
      if (gwGoogleLabel) gwGoogleLabel.textContent = 'Sign up with Google';
    } else {
      gwCardTitle.textContent = 'Welcome Back!';
      gwCardSubtitle.textContent = 'Login to your account or create a new one to get started.';
      gwSubmitBtn.textContent = 'Login';
      gwFooterPrompt.textContent = "Don't have an account?";
      gwModeToggle.textContent = 'Sign up free';
      if (fieldSignupName) fieldSignupName.hidden = true;
      if (fieldSignupSkill) fieldSignupSkill.hidden = true;
      if (passStrengthMeter) passStrengthMeter.hidden = true;
      if (gwNameInput) gwNameInput.required = false;
      if (gwGoogleLabel) gwGoogleLabel.textContent = 'Continue with Google';
    }
  }

  if (tabLogin) tabLogin.addEventListener('click', () => setGatewayMode(false));
  if (tabSignup) tabSignup.addEventListener('click', () => setGatewayMode(true));
  if (gwNavLoginBtn) gwNavLoginBtn.addEventListener('click', () => setGatewayMode(false));
  if (gwNavSignupBtn) gwNavSignupBtn.addEventListener('click', () => setGatewayMode(true));
  if (gwTopSignupBtn) gwTopSignupBtn.addEventListener('click', () => setGatewayMode(true));
  if (gwModeToggle) gwModeToggle.addEventListener('click', () => setGatewayMode(!isSignUpMode));

  // Password Strength
  function updatePasswordStrength(val) {
    if (!strengthBarFill || !strengthVal) return;
    const len = val.length;
    let score = 0;
    if (len >= 6) score++;
    if (/[A-Z]/.test(val) && /[0-9]/.test(val)) score++;
    if (len >= 10 || /[^A-Za-z0-9]/.test(val)) score++;

    strengthBarFill.className = 'strength-bar-fill';
    strengthVal.className = 'strength-val';

    if (len === 0) {
      strengthBarFill.style.width = '0%';
      strengthVal.textContent = 'Enter password';
    } else if (score <= 1) {
      strengthBarFill.classList.add('weak');
      strengthVal.classList.add('weak');
      strengthVal.textContent = 'Weak';
    } else if (score === 2) {
      strengthBarFill.classList.add('medium');
      strengthVal.classList.add('medium');
      strengthVal.textContent = 'Good';
    } else {
      strengthBarFill.classList.add('strong');
      strengthVal.classList.add('strong');
      strengthVal.textContent = 'Strong (Secure)';
    }
  }

  if (gwPassInput) {
    gwPassInput.addEventListener('input', () => {
      clearAuthError();
      if (isSignUpMode) updatePasswordStrength(gwPassInput.value);
    });
  }

  if (gwPassToggle && gwPassInput) {
    gwPassToggle.addEventListener('click', () => {
      const isPass = gwPassInput.type === 'password';
      gwPassInput.type = isPass ? 'text' : 'password';
      gwPassToggle.textContent = isPass ? '🙈' : '👁';
    });
  }

  // Mascot Playful Focus
  const mascotEl = document.querySelector('.mascot-companion');
  if (gwPassInput && mascotEl) {
    gwPassInput.addEventListener('focus', () => mascotEl.style.transform = 'translateY(-14px) rotate(-8deg) scale(1.08)');
    gwPassInput.addEventListener('blur', () => mascotEl.style.transform = '');
  }

  // -------------------------------------------------------------
  // 4. HERO ANIMATIONS & 3D PARALLAX
  // -------------------------------------------------------------
  function triggerHeroAnimationSequence() {
    const heroTitleWords = document.querySelectorAll('#hero-stagger-title .stagger-word');
    const userCard1 = document.querySelector('#user-card-1');
    const userCard2 = document.querySelector('#user-card-2');
    const centerHub = document.querySelector('#hero-center-hub');
    const networkSvg = document.querySelector('#hero-network-svg');
    const matchPanel = document.querySelector('#hero-match-panel');
    const connectBtn = document.querySelector('.connect-pulse-btn');

    if (userCard1) {
      userCard1.style.opacity = '0';
      userCard1.style.transform = 'translateY(35px)';
      userCard1.style.transition = 'opacity 0.75s cubic-bezier(0.16, 1, 0.3, 1), transform 0.75s cubic-bezier(0.16, 1, 0.3, 1)';
    }
    if (userCard2) {
      userCard2.style.opacity = '0';
      userCard2.style.transform = 'translateY(35px)';
      userCard2.style.transition = 'opacity 0.75s cubic-bezier(0.16, 1, 0.3, 1), transform 0.75s cubic-bezier(0.16, 1, 0.3, 1)';
    }
    if (centerHub) {
      centerHub.style.opacity = '0';
      centerHub.style.transform = 'translate(-50%, -50%) scale(0.65)';
      centerHub.style.transition = 'opacity 0.8s cubic-bezier(0.34, 1.56, 0.64, 1), transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1)';
    }
    if (networkSvg) {
      networkSvg.style.opacity = '0';
      networkSvg.style.transition = 'opacity 0.9s ease';
    }
    if (matchPanel) {
      matchPanel.style.opacity = '0';
      matchPanel.style.transform = 'translateX(50px)';
      matchPanel.style.transition = 'opacity 0.85s cubic-bezier(0.16, 1, 0.3, 1), transform 0.85s cubic-bezier(0.16, 1, 0.3, 1)';
    }

    heroTitleWords.forEach((word, index) => {
      word.style.animation = 'none';
      word.offsetHeight;
      word.style.animation = `wordRevealCascade 0.65s cubic-bezier(0.16, 1, 0.3, 1) forwards ${(index + 1) * 70}ms`;
    });

    setTimeout(() => {
      if (userCard1) { userCard1.style.opacity = '1'; userCard1.style.transform = 'translateY(0)'; }
      if (userCard2) { userCard2.style.opacity = '1'; userCard2.style.transform = 'translateY(0)'; }
    }, 380);

    setTimeout(() => {
      if (centerHub) {
        centerHub.style.opacity = '1';
        centerHub.style.transform = 'translate(-50%, -50%) scale(1)';
        const aura = centerHub.querySelector('.hub-neon-aura');
        if (aura) aura.style.animation = 'hubAuraPulse 3.8s ease-in-out infinite alternate';
      }
    }, 800);

    setTimeout(() => {
      if (networkSvg) networkSvg.style.opacity = '1';
    }, 1150);

    setTimeout(() => {
      if (matchPanel) { matchPanel.style.opacity = '1'; matchPanel.style.transform = 'translateX(0)'; }
    }, 1500);

    setTimeout(() => {
      if (connectBtn) connectBtn.classList.add('pulse-active');
      if (userCard1) userCard1.style.transition = 'box-shadow 0.3s ease, border-color 0.3s ease';
      if (userCard2) userCard2.style.transition = 'box-shadow 0.3s ease, border-color 0.3s ease';
      if (centerHub) centerHub.style.transition = '';
      if (matchPanel) matchPanel.style.transition = 'box-shadow 0.3s ease';
    }, 2100);
  }

  // 3D Parallax
  const heroVisual = document.querySelector('#hero-interactive-stage');
  if (heroVisual && !prefersReducedMotion) {
    let targetX = 0, targetY = 0;
    let currentX = 0, currentY = 0;
    let isHovering = false;

    heroVisual.addEventListener('pointermove', (e) => {
      const rect = heroVisual.getBoundingClientRect();
      targetX = (e.clientX - rect.left) / rect.width - 0.5;
      targetY = (e.clientY - rect.top) / rect.height - 0.5;
      isHovering = true;
    });

    heroVisual.addEventListener('pointerleave', () => {
      targetX = 0; targetY = 0; isHovering = false;
    });

    function applyParallax() {
      currentX += (targetX - currentX) * 0.08;
      currentY += (targetY - currentY) * 0.08;

      const userCard1 = document.querySelector('#user-card-1');
      const userCard2 = document.querySelector('#user-card-2');
      const centerHub = document.querySelector('#hero-center-hub');
      const matchPanel = document.querySelector('#hero-match-panel');

      if (isHovering || Math.abs(currentX) > 0.001 || Math.abs(currentY) > 0.001) {
        if (centerHub) {
          centerHub.style.transform = `translate(calc(-50% + ${currentX * -20}px), calc(-50% + ${currentY * -20}px)) rotateY(${currentX * 14}deg) rotateX(${-currentY * 14}deg)`;
        }
        if (userCard1) {
          userCard1.style.transform = `translate3d(${currentX * 24}px, ${currentY * 24}px, 0) rotateY(${currentX * 12}deg) rotateX(${-currentY * 12}deg)`;
        }
        if (userCard2) {
          userCard2.style.transform = `translate3d(${currentX * -18}px, ${currentY * -18}px, 0) rotateY(${currentX * 10}deg) rotateX(${-currentY * 10}deg)`;
        }
        if (matchPanel) {
          matchPanel.style.transform = `translate3d(${currentX * 12}px, ${currentY * 12}px, 0) rotateY(${currentX * 6}deg) rotateX(${-currentY * 6}deg)`;
        }
      }
      requestAnimationFrame(applyParallax);
    }
    requestAnimationFrame(applyParallax);
  }

  // -------------------------------------------------------------
  // 5. UNLOCK & LOAD REAL USER DATA FROM BACKEND
  // -------------------------------------------------------------
  async function unlockWebsiteAccess(user, token) {
    currentUser = user;
    if (token) localStorage.setItem('skillswap_token', token);

    // Update Header and Profile Badges
    const firstName = (user.full_name || 'Swapper').split(' ')[0];
    if (headerUserName) headerUserName.textContent = firstName;
    if (dropdownUserName) dropdownUserName.textContent = user.full_name;
    if (dropdownUserEmail) dropdownUserEmail.textContent = user.email;

    const myProfileName = document.querySelector('#my-profile-name');
    const myProfileRole = document.querySelector('#my-profile-role');
    const myProfileAvatar = document.querySelector('#my-profile-avatar-img');

    if (myProfileName) myProfileName.textContent = user.full_name;
    if (myProfileRole) myProfileRole.textContent = user.role_title || 'Skill Swapper • Open for Mutual Exchanges';
    if (myProfileAvatar && user.avatar_url) myProfileAvatar.src = user.avatar_url;

    // Update Goals Display
    updateGoalsDisplay({
      learning: user.skills_learn || 'Full-Stack Next.js & AI Agents',
      project: user.project_interest || 'Building an AI Agent Developer Platform',
      teach: user.skills_teach || 'UI/UX Design, Figma & Design Systems',
      cadence: user.cadence || 'Weekly Google Meet Sessions'
    });

    // Reveal App
    authGateway.classList.add('gateway-unlocked');
    mainApp.hidden = false;
    body.classList.remove('modal-open');

    // Trigger animations
    triggerHeroAnimationSequence();

    // Load dynamic real database sections
    await Promise.all([
      loadRegisteredUsersAndRender(),
      loadHeroMatches(),
      loadProposals(),
      loadConversations(),
      loadReviews()
    ]);

    showToast(`Welcome back, ${firstName}!`, '🎉');
  }

  function lockWebsiteAccess() {
    localStorage.removeItem('skillswap_token');
    currentUser = null;
    authGateway.classList.remove('gateway-unlocked');
    mainApp.hidden = true;
    if (userDropdownMenu) userDropdownMenu.classList.remove('show');
    showToast('Session ended. SkillSwap locked.', '🔒');
  }

  if (appLogoutBtn) appLogoutBtn.addEventListener('click', lockWebsiteAccess);
  if (siteNavLoginBtn) siteNavLoginBtn.addEventListener('click', () => { lockWebsiteAccess(); setGatewayMode(false); });
  if (siteNavSignupBtn) siteNavSignupBtn.addEventListener('click', () => { lockWebsiteAccess(); setGatewayMode(true); });

  // -------------------------------------------------------------
  // 6. GATEWAY FORM SUBMIT (Sign Up / Login)
  // -------------------------------------------------------------
  if (gatewayAuthForm) {
    gatewayAuthForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      clearAuthError();

      const email = gwEmailInput ? gwEmailInput.value.trim() : '';
      const password = gwPassInput ? gwPassInput.value : '';
      const fullName = (gwNameInput && gwNameInput.value.trim()) || '';
      const skillTeach = (gwSkillInput && gwSkillInput.value.trim()) || '';

      if (!email || !password) {
        showAuthError('Invalid email or password. Please try again.');
        return;
      }

      gwSubmitBtn.disabled = true;
      gwSubmitBtn.textContent = 'Connecting...';

      if (isSignUpMode) {
        // Sign Up Free
        const res = await api('/api/auth/signup', {
          method: 'POST',
          body: JSON.stringify({
            email,
            password,
            full_name: fullName || email.split('@')[0],
            skills_teach: skillTeach,
            skills_learn: 'Web Development, UI Design'
          })
        });

        gwSubmitBtn.disabled = false;
        gwSubmitBtn.textContent = 'Create Your Free Account →';

        if (res.ok && res.user && res.token) {
          unlockWebsiteAccess(res.user, res.token);
          showToast('Account created and saved in database!', '✨');
        } else {
          showAuthError(res.error || 'Failed to create account. Please try again.');
        }
      } else {
        // Login
        const res = await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({ email, password })
        });

        gwSubmitBtn.disabled = false;
        gwSubmitBtn.textContent = 'Login';

        if (res.ok && res.user && res.token) {
          unlockWebsiteAccess(res.user, res.token);
        } else {
          // Exact requirement error message
          showAuthError(res.error || 'Invalid email or password. Please try again.');
        }
      }
    });
  }

  // -------------------------------------------------------------
  // 7. GOOGLE ACCOUNT SIGN-IN MODAL FLOW
  // -------------------------------------------------------------
  const googleLoginModal = document.querySelector('#google-login-modal');
  const googleModalClose = document.querySelector('#google-modal-close');
  const googleAccAlex = document.querySelector('#google-acc-alex');
  const googleCustomEmail = document.querySelector('#google-custom-email');
  const googleCustomSubmit = document.querySelector('#google-custom-submit-btn');

  function openGoogleModal() {
    if (!googleLoginModal) return;
    googleLoginModal.classList.add('open');
    googleLoginModal.setAttribute('aria-hidden', 'false');
    body.classList.add('modal-open');
  }

  function closeGoogleModal() {
    if (!googleLoginModal) return;
    googleLoginModal.classList.remove('open');
    googleLoginModal.setAttribute('aria-hidden', 'true');
    body.classList.remove('modal-open');
  }

  if (gwGoogleBtn) gwGoogleBtn.addEventListener('click', openGoogleModal);
  if (googleModalClose) googleModalClose.addEventListener('click', closeGoogleModal);
  if (googleLoginModal) {
    googleLoginModal.addEventListener('click', (e) => {
      if (e.target === googleLoginModal) closeGoogleModal();
    });
  }

  async function performGoogleAuth(email, name = null) {
    const formattedName = name || (email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1));
    const res = await api('/api/auth/google', {
      method: 'POST',
      body: JSON.stringify({
        email,
        full_name: formattedName,
        google_id: `g_${email}`
      })
    });

    if (res.ok && res.user && res.token) {
      closeGoogleModal();
      unlockWebsiteAccess(res.user, res.token);
      showToast(`Authenticated with Google as ${res.user.full_name}`, '✓');
    } else {
      showToast(res.error || 'Google authentication failed.', '⚠️');
    }
  }

  if (googleAccAlex) {
    googleAccAlex.addEventListener('click', () => {
      performGoogleAuth('alex.chen@gmail.com', 'Alex Chen');
    });
  }

  if (googleCustomSubmit) {
    googleCustomSubmit.addEventListener('click', () => {
      const email = (googleCustomEmail && googleCustomEmail.value.trim()) || 'learner@gmail.com';
      performGoogleAuth(email);
    });
  }

  // Instant Guest Access / Auto-Seed Option
  if (gwDemoBtn || gwTopDemoBtn) {
    const handleGuest = async () => {
      // Seed database if empty so guest immediately experiences a living community
      await api('/api/seed', { method: 'POST' });
      // Authenticate as a real registered user or guest in DB
      performGoogleAuth('explorer@skillswap.io', 'Guest Explorer');
    };
    if (gwDemoBtn) gwDemoBtn.addEventListener('click', handleGuest);
    if (gwTopDemoBtn) gwTopDemoBtn.addEventListener('click', handleGuest);
  }

  // User Dropdown in Header
  if (userMenuBtn && userDropdownMenu) {
    userMenuBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      const isShown = userDropdownMenu.classList.toggle('show');
      userMenuBtn.setAttribute('aria-expanded', String(isShown));
    });

    document.addEventListener('click', (e) => {
      if (!userMenuBtn.contains(e.target) && !userDropdownMenu.contains(e.target)) {
        userDropdownMenu.classList.remove('show');
        userMenuBtn.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // -------------------------------------------------------------
  // 8. DYNAMIC DISCOVER & SEARCH PIPELINE (Real DB Users)
  // -------------------------------------------------------------
  const peopleGrid = document.querySelector('#people-grid');
  const searchInput = document.querySelector('#skill-search');
  const searchButton = document.querySelector('#search-button');
  const searchClear = document.querySelector('#search-clear');
  const statusText = document.querySelector('#search-status');
  const emptyState = document.querySelector('#empty-state');
  const activeChipContainer = document.querySelector('#active-chip-container');
  const activeChipText = document.querySelector('#active-chip-text');
  const activeChipClear = document.querySelector('#active-chip-clear');
  const filterButtons = [...document.querySelectorAll('.filter')];
  const quickSkillSelect = document.querySelector('#quick-skill-select');
  const quickSearchBtn = document.querySelector('#quick-search-btn');
  const quickPills = document.querySelectorAll('.quick-pill');

  let selectedCategory = 'all';

  async function loadRegisteredUsersAndRender() {
    const res = await api('/api/users');
    if (res.ok && Array.isArray(res.users)) {
      allRegisteredUsers = res.users;
      renderPeerCards(allRegisteredUsers);
    }
  }

  function renderPeerCards(users, highlightSkill = null) {
    if (!peopleGrid) return;
    peopleGrid.innerHTML = '';

    const query = searchInput ? searchInput.value.trim().toLowerCase() : '';

    // Filter out users who have not added any skills
    const usersWithSkills = users.filter(u => {
      return (u.skills_teach && u.skills_teach.trim()) || (u.skills_learn && u.skills_learn.trim());
    });

    // Don't show the logged-in user in their own discovery search
    const peers = currentUser ? usersWithSkills.filter(u => u.id !== currentUser.id) : usersWithSkills;

    let matchCount = 0;

    peers.forEach(peer => {
      const skillsTeach = peer.skills_teach || '';
      const skillsLearn = peer.skills_learn || '';
      const fullSearchText = `${peer.full_name} ${peer.role_title} ${skillsTeach} ${skillsLearn} ${peer.project_interest || ''}`.toLowerCase();

      // Category matching
      let matchesCat = selectedCategory === 'all';
      if (!matchesCat) {
        if (selectedCategory === 'tech' && /(python|web|react|node|html|cloud|devops|engineer|software)/i.test(fullSearchText)) matchesCat = true;
        if (selectedCategory === 'design' && /(design|figma|ui|ux|brand|visual|motion)/i.test(fullSearchText)) matchesCat = true;
        if (selectedCategory === 'creative' && /(guitar|music|illustration|storytelling|video)/i.test(fullSearchText)) matchesCat = true;
        if (selectedCategory === 'business' && /(business|strategy|freelance|marketing|product)/i.test(fullSearchText)) matchesCat = true;
        if (selectedCategory === 'language' && /(language|english|speaking|presentation)/i.test(fullSearchText)) matchesCat = true;
      }

      const matchesQuery = !query || fullSearchText.includes(query);

      if (matchesCat && matchesQuery) {
        matchCount++;

        const card = document.createElement('article');
        card.className = 'person-card tilt-card reveal in-view';
        if (highlightSkill && fullSearchText.includes(highlightSkill.toLowerCase())) {
          card.classList.add('search-highlight');
        }

        // Skills pills
        const teachPills = skillsTeach.split(/[,·|]/).map(s => s.trim()).filter(Boolean);
        const pillsHtml = teachPills.slice(0, 4).map(skill => `<span data-skill="${escapeHtml(skill)}">${escapeHtml(skill)}</span>`).join('');

        const avatarSrc = peer.avatar_url || 'person 2.jpeg';
        const ratingDisplay = peer.avg_rating ? `${peer.avg_rating} ★` : 'New Swapper';

        card.innerHTML = `
          <div class="person-top">
            <div class="profile-portrait">
              <img src="${escapeHtml(avatarSrc)}" alt="${escapeHtml(peer.full_name)}" loading="lazy" />
              <i>●</i>
            </div>
            <button class="heart-button" type="button" aria-label="Save to favorites">♡</button>
          </div>
          <div class="person-name">
            <h3>${escapeHtml(peer.full_name)} <span class="verified">✓</span></h3>
            <span>${ratingDisplay}</span>
          </div>
          <p>${escapeHtml(peer.role_title || 'Lifelong learner on SkillSwap.')}</p>
          <div class="skill-pills">
            ${pillsHtml || '<span data-skill="Learning">Active Learner</span>'}
          </div>
          <div class="peer-exchange-needs">
            <div class="wants">
              <span>🎯 Wants to learn:</span>
              <strong>${escapeHtml(peer.skills_learn || 'Open to proposals')}</strong>
            </div>
            ${peer.project_interest ? `
            <div class="project-interest">
              <span>🚀 Project interest:</span>
              <strong>${escapeHtml(peer.project_interest)}</strong>
            </div>` : ''}
          </div>
          <button class="button button-card open-proposal-btn" type="button" data-id="${peer.id}" data-name="${escapeHtml(peer.full_name)}" data-teach="${escapeHtml(peer.skills_teach || '')}" data-learn="${escapeHtml(peer.skills_learn || '')}">
            Send exchange request <span aria-hidden="true">→</span>
          </button>
        `;

        peopleGrid.appendChild(card);
      }
    });

    // Update Status
    if (statusText) {
      if (query) {
        statusText.textContent = `${matchCount} match${matchCount === 1 ? '' : 'es'} for “${searchInput.value.trim()}”`;
      } else if (selectedCategory !== 'all') {
        statusText.textContent = `Showing ${matchCount} peer${matchCount === 1 ? '' : 's'} in ${selectedCategory}`;
      } else {
        statusText.textContent = `Showing ${matchCount} registered community peer${matchCount === 1 ? '' : 's'}`;
      }
    }

    if (activeChipContainer && activeChipText) {
      if (query || selectedCategory !== 'all') {
        activeChipContainer.hidden = false;
        activeChipText.textContent = query ? `Skill: ${searchInput.value.trim()}` : `Category: ${selectedCategory}`;
      } else {
        activeChipContainer.hidden = true;
      }
    }

    if (emptyState) {
      emptyState.hidden = matchCount > 0;
    }

    // Attach proposal triggers
    peopleGrid.querySelectorAll('.open-proposal-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        openProposalModal({
          id: btn.dataset.id,
          name: btn.dataset.name,
          teach: btn.dataset.teach,
          learn: btn.dataset.learn
        });
      });
    });

    // Attach favorites hearts
    peopleGrid.querySelectorAll('.heart-button').forEach(btn => {
      btn.addEventListener('click', () => {
        const isLiked = btn.classList.toggle('liked');
        btn.textContent = isLiked ? '♥' : '♡';
        showToast(isLiked ? 'Saved peer to favorites' : 'Removed from favorites', isLiked ? '💖' : '🤍');
      });
    });

    // Attach skill pill clicks
    peopleGrid.querySelectorAll('.skill-pills span').forEach(pill => {
      pill.addEventListener('click', (e) => {
        e.stopPropagation();
        executeFindYourPeople(pill.dataset.skill || pill.textContent.trim());
      });
    });
  }

  function executeFindYourPeople(skill) {
    if (!skill) skill = 'Brand strategy';
    if (searchInput) searchInput.value = skill;

    const lower = skill.toLowerCase();
    let targetCat = 'all';
    if (/python|web|react|node|html/i.test(lower)) targetCat = 'tech';
    else if (/brand|motion|design|figma/i.test(lower)) targetCat = 'design';
    else if (/illustration|guitar|music/i.test(lower)) targetCat = 'creative';
    else if (/photography|ux writing|business/i.test(lower)) targetCat = 'business';

    selectedCategory = targetCat;
    filterButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.filter === targetCat));

    const discoverSection = document.querySelector('#discover');
    if (discoverSection) discoverSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

    setTimeout(() => {
      renderPeerCards(allRegisteredUsers, skill);
      showToast(`Showing verified peers for “${skill}”`, '🔍');
    }, 350);
  }

  if (quickSearchBtn) {
    quickSearchBtn.addEventListener('click', (e) => {
      e.preventDefault();
      const chosen = quickSkillSelect ? quickSkillSelect.value : '';
      if (!chosen) {
        showToast('Please pick a skill or click a popular pill below!', '💡');
        if (quickSkillSelect) quickSkillSelect.focus();
        return;
      }
      executeFindYourPeople(chosen);
    });
  }

  if (quickSkillSelect) {
    quickSkillSelect.addEventListener('change', () => {
      if (quickSkillSelect.value) executeFindYourPeople(quickSkillSelect.value);
    });
  }

  quickPills.forEach(pill => {
    pill.addEventListener('click', () => {
      const skill = pill.dataset.skill;
      if (quickSkillSelect) quickSkillSelect.value = skill;
      quickPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      executeFindYourPeople(skill);
    });
  });

  if (searchButton) searchButton.addEventListener('click', () => renderPeerCards(allRegisteredUsers));
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      if (searchClear) searchClear.hidden = !searchInput.value;
      renderPeerCards(allRegisteredUsers);
    });
  }
  if (searchClear) {
    searchClear.addEventListener('click', () => {
      searchInput.value = '';
      searchClear.hidden = true;
      renderPeerCards(allRegisteredUsers);
      searchInput.focus();
    });
  }
  if (activeChipClear) {
    activeChipClear.addEventListener('click', () => {
      if (searchInput) searchInput.value = '';
      selectedCategory = 'all';
      filterButtons.forEach(btn => btn.classList.toggle('active', btn.dataset.filter === 'all'));
      renderPeerCards(allRegisteredUsers);
    });
  }

  filterButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      filterButtons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedCategory = btn.dataset.filter || 'all';
      renderPeerCards(allRegisteredUsers);
    });
  });

  // -------------------------------------------------------------
  // 9. DYNAMIC HERO MATCHES & PEER CARDS (Real Database Info)
  // -------------------------------------------------------------
  async function loadHeroMatches() {
    const res = await api('/api/matches');
    if (!res.ok || !Array.isArray(res.matches)) return;
    const matches = res.matches;

    const userCard1 = document.querySelector('#user-card-1');
    const userCard2 = document.querySelector('#user-card-2');
    const heroMatchPanel = document.querySelector('#hero-match-panel');

    if (matches.length > 0 && userCard1) {
      const p1 = matches[0];
      userCard1.querySelector('.peer-name').innerHTML = `${escapeHtml(p1.full_name)} <span class="verified-dot">✓</span>`;
      userCard1.querySelector('.peer-role').textContent = p1.role_title || 'Community Swapper';
      userCard1.querySelector('.peer-avatar img').src = p1.avatar_url || 'mim.jpg';
      const teachSpan = userCard1.querySelector('.tag-teach');
      const learnSpan = userCard1.querySelector('.tag-learn');
      if (teachSpan) teachSpan.textContent = `Teach: ${(p1.skills_teach || 'Design').split(',')[0]}`;
      if (learnSpan) learnSpan.textContent = `Learn: ${(p1.skills_learn || 'Coding').split(',')[0]}`;
    }

    if (matches.length > 1 && userCard2) {
      const p2 = matches[1];
      userCard2.querySelector('.peer-name').innerHTML = `${escapeHtml(p2.full_name)} <span class="verified-dot">✓</span>`;
      userCard2.querySelector('.peer-role').textContent = p2.role_title || 'Full-Stack Engineer';
      userCard2.querySelector('.peer-avatar img').src = p2.avatar_url || 'saif.jpg';
      const teachSpan = userCard2.querySelector('.tag-teach');
      const learnSpan = userCard2.querySelector('.tag-learn');
      if (teachSpan) teachSpan.textContent = `Teach: ${(p2.skills_teach || 'Development').split(',')[0]}`;
      if (learnSpan) learnSpan.textContent = `Learn: ${(p2.skills_learn || 'Design').split(',')[0]}`;
    }

    if (matches.length > 0 && heroMatchPanel) {
      const topMatch = matches[0];
      const featuredArt = heroMatchPanel.querySelector('.featured-match');
      if (featuredArt) {
        featuredArt.querySelector('.profile-portrait img').src = topMatch.avatar_url || 'miraz.jpg';
        featuredArt.querySelector('.match-person p').innerHTML = `${escapeHtml(topMatch.full_name)} <span class="verified">✓</span>`;
        featuredArt.querySelector('.match-person small').textContent = `${topMatch.role_title || 'Brand Architect'}`;
        const ratingEl = featuredArt.querySelector('.match-footer .rating');
        if (ratingEl) {
          ratingEl.innerHTML = topMatch.avg_rating ? `★ ${topMatch.avg_rating} <small>(${topMatch.review_count} review${topMatch.review_count === 1 ? '' : 's'})</small>` : '★ New <small>(Verified)</small>';
        }

        const connectBtn = featuredArt.querySelector('.connect-pulse-btn');
        if (connectBtn) {
          connectBtn.onclick = () => {
            openProposalModal({
              id: topMatch.id,
              name: topMatch.full_name,
              teach: topMatch.skills_teach,
              learn: topMatch.skills_learn
            });
          };
        }
      }
    }
  }

  // -------------------------------------------------------------
  // 10. REAL MESSENGER CHAT & GOOGLE MEET (Connected to DB)
  // -------------------------------------------------------------
  const chatConversationsBar = document.querySelector('#chat-conversations-bar');
  const chatPartnerAvatar = document.querySelector('#chat-partner-avatar');
  const chatPartnerName = document.querySelector('#chat-partner-name');
  const chatPartnerStatus = document.querySelector('#chat-partner-status');
  const chatMessages = document.querySelector('#chat-messages');
  const chatForm = document.querySelector('#chat-form');
  const chatInput = document.querySelector('#chat-input');
  const chatRatePartnerBtn = document.querySelector('#chat-rate-partner-btn');

  const activeMeetUrlEl = document.querySelector('#active-meet-url');
  const copyMeetLinkBtn = document.querySelector('#copy-meet-link-btn');
  const openMeetModalBtn = document.querySelector('#open-meet-modal-btn');
  const meetLinkModal = document.querySelector('#meet-link-modal');
  const meetModalClose = document.querySelector('#meet-modal-close');
  const meetModalCancel = document.querySelector('#meet-modal-cancel');
  const meetShareForm = document.querySelector('#meet-share-form');
  const inputMeetUrl = document.querySelector('#input-meet-url');
  const generateMeetBtn = document.querySelector('#generate-meet-btn');
  const joinSessionBtn = document.querySelector('#join-session');

  const DEFAULT_MEET_URL = 'https://meet.google.com/qmv-ytpk-zbw';
  let currentMeetUrl = DEFAULT_MEET_URL;

  function updateActiveMeet(url) {
    currentMeetUrl = url || DEFAULT_MEET_URL;
    if (activeMeetUrlEl) {
      activeMeetUrlEl.href = currentMeetUrl;
      activeMeetUrlEl.textContent = currentMeetUrl.replace(/^https?:\/\//, '');
    }
    if (inputMeetUrl) inputMeetUrl.value = currentMeetUrl;
  }

  async function loadConversations() {
    const res = await api('/api/conversations');
    if (!res.ok || !Array.isArray(res.conversations)) return;
    userConversations = res.conversations;

    if (chatConversationsBar) {
      chatConversationsBar.innerHTML = '';
      if (userConversations.length === 0) {
        chatConversationsBar.innerHTML = '<span style="font-size: 11px; color: var(--muted); padding: 4px 8px;">No active conversations yet. Propose an exchange to start chatting!</span>';
      } else {
        userConversations.forEach((conv, idx) => {
          const peerName = conv.other_user ? conv.other_user.full_name : 'Peer';
          const tab = document.createElement('button');
          tab.type = 'button';
          tab.className = `chat-conv-tab${(activeConversationId === conv.id || (!activeConversationId && idx === 0)) ? ' active' : ''}`;
          tab.innerHTML = `💬 ${escapeHtml(peerName.split(' ')[0])}`;
          tab.addEventListener('click', () => selectConversation(conv));
          chatConversationsBar.appendChild(tab);
        });
      }
    }

    if (userConversations.length > 0) {
      const selected = activeConversationId ? userConversations.find(c => c.id === activeConversationId) : userConversations[0];
      if (selected) selectConversation(selected);
    }
  }

  async function selectConversation(conv) {
    activeConversationId = conv.id;
    activeConversationPeer = conv.other_user;

    if (chatConversationsBar) {
      chatConversationsBar.querySelectorAll('.chat-conv-tab').forEach((tab, i) => {
        tab.classList.toggle('active', userConversations[i] && userConversations[i].id === conv.id);
      });
    }

    if (activeConversationPeer) {
      if (chatPartnerName) chatPartnerName.textContent = activeConversationPeer.full_name;
      if (chatPartnerAvatar && activeConversationPeer.avatar_url) chatPartnerAvatar.src = activeConversationPeer.avatar_url;
      if (chatPartnerStatus) chatPartnerStatus.innerHTML = '<i></i> Active exchange partner';
    }

    if (conv.meet_url) updateActiveMeet(conv.meet_url);

    // Load messages from DB
    await loadConversationMessages(conv.id);
  }

  async function loadConversationMessages(convId) {
    if (!chatMessages) return;
    const res = await api(`/api/conversations/${convId}/messages`);
    if (res.ok && Array.isArray(res.messages)) {
      chatMessages.innerHTML = '<p class="chat-date">Real-Time Secure Messenger</p>';
      if (res.messages.length === 0) {
        chatMessages.innerHTML += '<div class="message incoming">Say hello! Agree on your goals and schedule your Google Meet session.</div>';
      } else {
        res.messages.forEach(msg => {
          const isOutgoing = currentUser && msg.sender_id === currentUser.id;
          const msgEl = document.createElement('div');
          msgEl.className = `message ${isOutgoing ? 'outgoing' : 'incoming'}`;
          
          if (msg.text.includes('meet.google.com')) {
            const urlMatch = msg.text.match(/https?:\/\/meet\.google\.com\/[a-z0-9-]+/i);
            const meetLink = urlMatch ? urlMatch[0] : '';
            msgEl.innerHTML = `📹 <strong>${escapeHtml(msg.sender_name || 'Partner')}:</strong> ${escapeHtml(msg.text)} <a href="${meetLink}" target="_blank" rel="noopener noreferrer" style="color:#60a5fa;text-decoration:underline;font-weight:700;display:block;margin-top:4px;">Join Google Meet →</a>`;
          } else {
            msgEl.textContent = msg.text;
          }

          chatMessages.appendChild(msgEl);
        });
      }
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  if (chatForm) {
    chatForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const text = chatInput ? chatInput.value.trim() : '';
      if (!text) return;

      if (!activeConversationId) {
        showToast('Please select or start an exchange first to send messages.', '💡');
        return;
      }

      chatInput.value = '';

      const res = await api(`/api/conversations/${activeConversationId}/messages`, {
        method: 'POST',
        body: JSON.stringify({ text })
      });

      if (res.ok && res.message) {
        const msgEl = document.createElement('div');
        msgEl.className = 'message outgoing';
        msgEl.textContent = text;
        chatMessages.appendChild(msgEl);
        msgEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } else {
        showToast(res.error || 'Failed to send message.', '⚠️');
      }
    });
  }

  // Google Meet Sharing
  if (copyMeetLinkBtn) {
    copyMeetLinkBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(currentMeetUrl).then(() => {
        showToast('Google Meet link copied to clipboard!', '📋');
      }).catch(() => {
        showToast(`Google Meet link: ${currentMeetUrl}`, '📋');
      });
    });
  }

  function openMeetModal() {
    if (!meetLinkModal) return;
    if (inputMeetUrl) inputMeetUrl.value = currentMeetUrl;
    meetLinkModal.classList.add('open');
    meetLinkModal.setAttribute('aria-hidden', 'false');
    body.classList.add('modal-open');
    setTimeout(() => inputMeetUrl && inputMeetUrl.focus(), 150);
  }

  function closeMeetModal() {
    if (!meetLinkModal) return;
    meetLinkModal.classList.remove('open');
    meetLinkModal.setAttribute('aria-hidden', 'true');
    body.classList.remove('modal-open');
  }

  if (openMeetModalBtn) openMeetModalBtn.addEventListener('click', openMeetModal);
  if (meetModalClose) meetModalClose.addEventListener('click', closeMeetModal);
  if (meetModalCancel) meetModalCancel.addEventListener('click', closeMeetModal);
  if (meetLinkModal) {
    meetLinkModal.addEventListener('click', (e) => {
      if (e.target === meetLinkModal) closeMeetModal();
    });
  }

  if (generateMeetBtn) {
    generateMeetBtn.addEventListener('click', () => {
      const seg = () => Math.random().toString(36).substring(2, 5);
      const genUrl = `https://meet.google.com/${seg()}-${seg()}-${seg()}`;
      if (inputMeetUrl) inputMeetUrl.value = genUrl;
      showToast(`Generated new Google Meet link: ${genUrl}`, '⚡');
    });
  }

  if (meetShareForm) {
    meetShareForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const newUrl = inputMeetUrl ? inputMeetUrl.value.trim() : currentMeetUrl;
      if (!newUrl) return;

      if (activeConversationId) {
        const res = await api(`/api/conversations/${activeConversationId}/meet`, {
          method: 'PUT',
          body: JSON.stringify({ meet_url: newUrl })
        });
        if (res.ok) {
          updateActiveMeet(newUrl);
          closeMeetModal();
          showToast('Google Meet link updated and shared with partner!', '📹');
          loadConversationMessages(activeConversationId);
        }
      } else {
        updateActiveMeet(newUrl);
        closeMeetModal();
        showToast('Google Meet link set ready!', '📹');
      }
    });
  }

  if (joinSessionBtn) {
    joinSessionBtn.addEventListener('click', (e) => {
      e.preventDefault();
      showToast(`Opening Google Meet: ${currentMeetUrl}...`, '📹');
      window.open(currentMeetUrl, '_blank', 'noopener,noreferrer');
    });
  }

  // -------------------------------------------------------------
  // 11. INCOMING PROPOSALS & EXCHANGE REQUESTS (Connected to DB)
  // -------------------------------------------------------------
  const incomingProposalsWrap = document.querySelector('#incoming-proposals-wrap');
  const requestModal = document.querySelector('#request-modal');
  const requestPerson = document.querySelector('#request-person');
  const requestForm = document.querySelector('#request-form');
  const requestReceiverId = document.querySelector('#request-receiver-id');
  const requestInputLearn = document.querySelector('#request-input-learn');
  const requestInputTeach = document.querySelector('#request-input-teach');
  const requestInputMsg = document.querySelector('#request-input-msg');
  const requestClose = document.querySelector('#request-modal-close');

  async function loadProposals() {
    if (!incomingProposalsWrap || !currentUser) return;
    const res = await api('/api/proposals');
    if (!res.ok || !Array.isArray(res.proposals)) return;

    const pendingIncoming = res.proposals.filter(p => p.receiver_id === currentUser.id && p.status === 'pending');

    if (pendingIncoming.length === 0) {
      incomingProposalsWrap.innerHTML = '';
      return;
    }

    incomingProposalsWrap.innerHTML = `
      <div class="incoming-proposals-box">
        <h4 style="margin: 0 0 10px; color: #10b981; font-size: 14px; font-weight: 700;">
          📬 Incoming Exchange Proposals (${pendingIncoming.length})
        </h4>
        ${pendingIncoming.map(p => `
          <div class="proposal-item">
            <div>
              <strong>${escapeHtml(p.sender_name)}</strong> wants to learn <em>“${escapeHtml(p.learn_skill)}”</em> and teach <em>“${escapeHtml(p.teach_skill)}”</em>.
              ${p.message ? `<small style="display:block;color:var(--muted);margin-top:2px;">"${escapeHtml(p.message)}"</small>` : ''}
            </div>
            <div class="proposal-actions">
              <button type="button" class="btn-accept" data-id="${p.id}">Accept & Chat</button>
              <button type="button" class="btn-reject" data-id="${p.id}">Decline</button>
            </div>
          </div>
        `).join('')}
      </div>
    `;

    incomingProposalsWrap.querySelectorAll('.btn-accept').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const res = await api(`/api/proposals/${id}/status`, {
          method: 'PUT',
          body: JSON.stringify({ status: 'accepted' })
        });
        if (res.ok) {
          showToast('Exchange proposal accepted! Conversation opened.', '🤝');
          await loadProposals();
          await loadConversations();
          const chatCard = document.querySelector('#chat-card');
          if (chatCard) chatCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      });
    });

    incomingProposalsWrap.querySelectorAll('.btn-reject').forEach(btn => {
      btn.addEventListener('click', async () => {
        const id = btn.dataset.id;
        const res = await api(`/api/proposals/${id}/status`, {
          method: 'PUT',
          body: JSON.stringify({ status: 'rejected' })
        });
        if (res.ok) {
          showToast('Proposal declined.', 'ℹ️');
          loadProposals();
        }
      });
    });
  }

  function openProposalModal(peer) {
    if (!requestModal) return;
    if (requestPerson) requestPerson.textContent = peer.name || 'your skill partner';
    if (requestReceiverId) requestReceiverId.value = peer.id || '';
    if (requestInputLearn) requestInputLearn.value = peer.teach ? peer.teach.split(',')[0].trim() : '';
    if (requestInputTeach) requestInputTeach.value = currentUser && currentUser.skills_teach ? currentUser.skills_teach.split(',')[0].trim() : '';

    requestModal.classList.add('open');
    requestModal.setAttribute('aria-hidden', 'false');
    body.classList.add('modal-open');
  }

  function closeProposalModal() {
    if (!requestModal) return;
    requestModal.classList.remove('open');
    requestModal.setAttribute('aria-hidden', 'true');
    body.classList.remove('modal-open');
  }

  if (requestClose) requestClose.addEventListener('click', closeProposalModal);
  if (requestModal) {
    requestModal.addEventListener('click', (e) => {
      if (e.target === requestModal) closeProposalModal();
    });
  }

  document.querySelectorAll('.open-request').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      // If a first peer exists in allRegisteredUsers, pre-select them
      const firstPeer = allRegisteredUsers.find(u => currentUser && u.id !== currentUser.id);
      openProposalModal({
        id: firstPeer ? firstPeer.id : '',
        name: firstPeer ? firstPeer.full_name : (btn.dataset.person || 'a new skill partner'),
        teach: firstPeer ? firstPeer.skills_teach : '',
        learn: firstPeer ? firstPeer.skills_learn : ''
      });
    });
  });

  if (requestForm) {
    requestForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const receiverId = requestReceiverId ? requestReceiverId.value : '';
      const learnSkill = requestInputLearn ? requestInputLearn.value.trim() : '';
      const teachSkill = requestInputTeach ? requestInputTeach.value.trim() : '';
      const message = requestInputMsg ? requestInputMsg.value.trim() : '';

      if (!receiverId) {
        showToast('Please select a peer from the Discover section to propose an exchange.', '💡');
        closeProposalModal();
        return;
      }

      const res = await api('/api/proposals', {
        method: 'POST',
        body: JSON.stringify({
          receiver_id: receiverId,
          learn_skill: learnSkill,
          teach_skill: teachSkill,
          message
        })
      });

      if (res.ok) {
        closeProposalModal();
        requestForm.reset();
        showToast('Exchange proposal sent successfully!', '💌');
      } else {
        showToast(res.error || 'Failed to send proposal.', '⚠️');
      }
    });
  }

  // -------------------------------------------------------------
  // 12. REAL USER REVIEWS & RATINGS (Connected to DB)
  // -------------------------------------------------------------
  const reviewStackContainer = document.querySelector('#review-stack-container');
  const ratingModal = document.querySelector('#rating-modal');
  const ratingModalClose = document.querySelector('#rating-modal-close');
  const ratingModalCancel = document.querySelector('#rating-modal-cancel');
  const ratingForm = document.querySelector('#rating-form');
  const ratingPartnerSelect = document.querySelector('#rating-partner-select');
  const ratingStarsPicker = document.querySelector('#rating-stars-picker');
  const inputRatingVal = document.querySelector('#input-rating-val');
  const inputReviewText = document.querySelector('#input-review-text');
  const openRatingModalBtn = document.querySelector('#open-rating-modal-btn');

  async function loadReviews() {
    if (!reviewStackContainer) return;
    const res = await api('/api/reviews');
    if (!res.ok || !Array.isArray(res.reviews)) return;

    const reviews = res.reviews;

    if (reviews.length === 0) {
      reviewStackContainer.innerHTML = `
        <div style="background: var(--card-bg); border: 1.5px dashed var(--line); border-radius: 16px; padding: 24px; text-align: center; color: var(--ink-soft);">
          <p style="font-size: 14px; margin: 0 0 10px;">No reviews submitted yet. Complete your first skill exchange to leave a review!</p>
        </div>
      `;
      return;
    }

    const firstTwo = reviews.slice(0, 2);
    let cardsHtml = '';

    firstTwo.forEach((rev, idx) => {
      const isFront = idx === 0;
      const stars = '★'.repeat(rev.rating) + '☆'.repeat(5 - rev.rating);
      const avatarSrc = rev.reviewer_avatar || 'person 6.jpeg';

      cardsHtml += `
        <article class="review-card ${isFront ? 'review-front' : 'review-back'}">
          <span class="rating" style="color: #f59e0b;">${stars}</span>
          <p>“${escapeHtml(rev.review_text)}”</p>
          <div>
            <span class="mini-portrait">
              <img src="${escapeHtml(avatarSrc)}" alt="${escapeHtml(rev.reviewer_name)}" />
            </span>
            <div>
              <strong>${escapeHtml(rev.reviewer_name)}</strong>
              <small>${escapeHtml(rev.reviewer_role || 'Skill Swapper')}</small>
            </div>
          </div>
        </article>
      `;
    });

    // Calculate real average
    const avg = (reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1);

    cardsHtml += `
      <span class="stat-bubble">
        <b>${avg}/5</b>
        <small>rating</small>
      </span>
    `;

    reviewStackContainer.innerHTML = cardsHtml;
  }

  function openRatingModal(preselectedUserId = null) {
    if (!ratingModal || !ratingPartnerSelect) return;

    ratingPartnerSelect.innerHTML = '<option value="" disabled selected>Select partner to review...</option>';
    const candidates = allRegisteredUsers.filter(u => currentUser && u.id !== currentUser.id);

    candidates.forEach(u => {
      const opt = document.createElement('option');
      opt.value = u.id;
      opt.textContent = `${u.full_name} (${u.role_title || 'Peer'})`;
      if (preselectedUserId && String(u.id) === String(preselectedUserId)) {
        opt.selected = true;
      }
      ratingPartnerSelect.appendChild(opt);
    });

    ratingModal.classList.add('open');
    ratingModal.setAttribute('aria-hidden', 'false');
    body.classList.add('modal-open');
  }

  function closeRatingModal() {
    if (!ratingModal) return;
    ratingModal.classList.remove('open');
    ratingModal.setAttribute('aria-hidden', 'true');
    body.classList.remove('modal-open');
  }

  if (openRatingModalBtn) openRatingModalBtn.addEventListener('click', () => openRatingModal());
  if (chatRatePartnerBtn) {
    chatRatePartnerBtn.addEventListener('click', () => {
      if (activeConversationPeer) openRatingModal(activeConversationPeer.id);
      else openRatingModal();
    });
  }

  if (ratingModalClose) ratingModalClose.addEventListener('click', closeRatingModal);
  if (ratingModalCancel) ratingModalCancel.addEventListener('click', closeRatingModal);
  if (ratingModal) {
    ratingModal.addEventListener('click', (e) => {
      if (e.target === ratingModal) closeRatingModal();
    });
  }

  // Star Rating Picker
  if (ratingStarsPicker) {
    const starBtns = ratingStarsPicker.querySelectorAll('.star-btn');
    starBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        const val = parseInt(btn.dataset.rating, 10);
        if (inputRatingVal) inputRatingVal.value = val;
        starBtns.forEach(b => {
          const bVal = parseInt(b.dataset.rating, 10);
          b.classList.toggle('active', bVal <= val);
        });
      });
    });
  }

  if (ratingForm) {
    ratingForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const revieweeId = ratingPartnerSelect ? ratingPartnerSelect.value : '';
      const rating = inputRatingVal ? inputRatingVal.value : '5';
      const reviewText = inputReviewText ? inputReviewText.value.trim() : '';

      if (!revieweeId || !reviewText) {
        showToast('Please select a partner and write your review.', '⚠️');
        return;
      }

      const res = await api('/api/reviews', {
        method: 'POST',
        body: JSON.stringify({
          reviewee_id: revieweeId,
          rating,
          review_text: reviewText
        })
      });

      if (res.ok) {
        closeRatingModal();
        ratingForm.reset();
        showToast('Review submitted and rating recorded in database!', '⭐');
        await loadReviews();
        await loadRegisteredUsersAndRender();
      } else {
        showToast(res.error || 'Failed to submit review.', '⚠️');
      }
    });
  }

  // -------------------------------------------------------------
  // 13. PROFILE & LEARNING GOALS MANAGEMENT (Connected to DB)
  // -------------------------------------------------------------
  function updateGoalsDisplay(goals) {
    const menuLearning = document.querySelector('#menu-user-learning');
    const menuProject = document.querySelector('#menu-user-project');
    const dispLearning = document.querySelector('#display-my-learning');
    const dispProject = document.querySelector('#display-my-project');
    const dispTeach = document.querySelector('#display-my-teach');
    const dispCadence = document.querySelector('#display-my-cadence');

    if (menuLearning) menuLearning.textContent = goals.learning;
    if (menuProject) menuProject.textContent = goals.project;
    if (dispLearning) dispLearning.textContent = goals.learning;
    if (dispProject) dispProject.textContent = goals.project;
    if (dispTeach) dispTeach.textContent = goals.teach;
    if (dispCadence) dispCadence.textContent = goals.cadence;

    const inputLearning = document.querySelector('#input-user-learning');
    const inputProject = document.querySelector('#input-user-project');
    const inputTeach = document.querySelector('#input-user-teach');
    const inputCadence = document.querySelector('#input-user-cadence');

    if (inputLearning) inputLearning.value = goals.learning;
    if (inputProject) inputProject.value = goals.project;
    if (inputTeach) inputTeach.value = goals.teach;
    if (inputCadence) inputCadence.value = goals.cadence;
  }

  const goalsModal = document.querySelector('#learning-goals-modal');
  const goalsModalClose = document.querySelector('#goals-modal-close');
  const goalsModalCancel = document.querySelector('#goals-modal-cancel');
  const goalsForm = document.querySelector('#learning-goals-form');
  const triggerGoalsModalBtn = document.querySelector('#trigger-goals-modal-btn');
  const menuEditGoalsBtn = document.querySelector('#menu-edit-goals-btn');
  const emptyStateEditBtn = document.querySelector('#empty-state-edit-btn');

  function openGoalsModal() {
    if (!goalsModal) return;
    goalsModal.classList.add('open');
    goalsModal.setAttribute('aria-hidden', 'false');
    body.classList.add('modal-open');
    const input = document.querySelector('#input-user-learning');
    if (input) setTimeout(() => input.focus(), 150);
  }

  function closeGoalsModal() {
    if (!goalsModal) return;
    goalsModal.classList.remove('open');
    goalsModal.setAttribute('aria-hidden', 'true');
    body.classList.remove('modal-open');
  }

  if (triggerGoalsModalBtn) triggerGoalsModalBtn.addEventListener('click', openGoalsModal);
  if (emptyStateEditBtn) emptyStateEditBtn.addEventListener('click', openGoalsModal);
  if (menuEditGoalsBtn) {
    menuEditGoalsBtn.addEventListener('click', () => {
      if (userDropdownMenu) userDropdownMenu.classList.remove('show');
      openGoalsModal();
    });
  }
  if (goalsModalClose) goalsModalClose.addEventListener('click', closeGoalsModal);
  if (goalsModalCancel) goalsModalCancel.addEventListener('click', closeGoalsModal);
  if (goalsModal) {
    goalsModal.addEventListener('click', (e) => {
      if (e.target === goalsModal) closeGoalsModal();
    });
  }

  if (goalsForm) {
    goalsForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const skills_learn = document.querySelector('#input-user-learning')?.value.trim() || '';
      const project_interest = document.querySelector('#input-user-project')?.value.trim() || '';
      const skills_teach = document.querySelector('#input-user-teach')?.value.trim() || '';
      const cadence = document.querySelector('#input-user-cadence')?.value || 'Weekly Google Meet Sessions';

      const res = await api('/api/users/profile', {
        method: 'PUT',
        body: JSON.stringify({
          skills_learn,
          project_interest,
          skills_teach,
          cadence
        })
      });

      if (res.ok && res.user) {
        currentUser = res.user;
        updateGoalsDisplay({
          learning: res.user.skills_learn,
          project: res.user.project_interest,
          teach: res.user.skills_teach,
          cadence: res.user.cadence
        });
        closeGoalsModal();
        showToast('Learning goals saved to database! Profile updated.', '🎯');
        await loadRegisteredUsersAndRender();
        await loadHeroMatches();
      } else {
        showToast(res.error || 'Failed to update profile.', '⚠️');
      }
    });
  }

  // -------------------------------------------------------------
  // 14. MISCELLANEOUS UI INTERACTIONS & THEME
  // -------------------------------------------------------------
  try {
    const savedTheme = localStorage.getItem('skillswap_theme');
    if (savedTheme === 'dark') body.dataset.theme = 'dark';
  } catch (e) {}

  const themeToggle = document.querySelector('.theme-toggle');
  if (themeToggle) {
    themeToggle.addEventListener('click', () => {
      const isDark = body.dataset.theme === 'dark';
      if (isDark) {
        delete body.dataset.theme;
        try { localStorage.setItem('skillswap_theme', 'light'); } catch (e) {}
        showToast('Light mode enabled', '☀️');
      } else {
        body.dataset.theme = 'dark';
        try { localStorage.setItem('skillswap_theme', 'dark'); } catch (e) {}
        showToast('Dark mode enabled', '🌙');
      }
    });
  }

  document.querySelectorAll('[data-scroll-target]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = document.querySelector(btn.dataset.scrollTarget);
      if (target) target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });

  const canTilt = window.matchMedia('(hover: hover) and (pointer: fine)').matches && !prefersReducedMotion;
  if (canTilt) {
    document.querySelectorAll('.tilt-card').forEach(card => {
      card.addEventListener('pointerenter', () => card.style.setProperty('--tilt-lift', '-5px'));
      card.addEventListener('pointermove', (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        card.style.setProperty('--tilt-x', `${(-py * 6).toFixed(2)}deg`);
        card.style.setProperty('--tilt-y', `${(px * 7).toFixed(2)}deg`);
      });
      card.addEventListener('pointerleave', () => {
        card.style.setProperty('--tilt-x', '0deg');
        card.style.setProperty('--tilt-y', '0deg');
        card.style.setProperty('--tilt-lift', '0px');
      });
    });
  }

  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeProposalModal();
      closeMeetModal();
      closeGoogleModal();
      closeGoalsModal();
      closeRatingModal();
    }
  });

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // -------------------------------------------------------------
  // 15. INITIALIZE APP ON PAGE LOAD
  // -------------------------------------------------------------
  async function checkInitialSession() {
    const token = localStorage.getItem('skillswap_token');
    if (token) {
      const res = await api('/api/auth/me');
      if (res.ok && res.user) {
        unlockWebsiteAccess(res.user, token);
        return;
      } else {
        localStorage.removeItem('skillswap_token');
      }
    }
  }

  checkInitialSession();

  console.log('%c SkillSwap Dynamic Platform %c Node.js + SQLite Connected ',
    'background:#3B66FF;color:#fff;font-weight:bold;padding:4px 8px;border-radius:4px 0 0 4px;',
    'background:#10B981;color:#fff;font-weight:bold;padding:4px 8px;border-radius:0 4px 4px 0;'
  );
})();

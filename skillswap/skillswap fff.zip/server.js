/**
 * SkillSwap Backend Server
 * High-performance RESTful API & Static Asset Server
 * Runs seamlessly on Node.js v24+ with zero external dependencies.
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const url = require('node:url');
const db = require('./database');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf'
};

// Helper to send JSON responses
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With'
  });
  res.end(JSON.stringify(data));
}

// Helper to parse JSON request body
function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 2 * 1024 * 1024) { // 2MB limit
        reject(new Error('Body payload too large'));
      }
    });
    req.on('end', () => {
      try {
        if (!body.trim()) return resolve({});
        const parsed = JSON.parse(body);
        resolve(parsed);
      } catch (err) {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

// Helper to authenticate request
function getAuthUser(req) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return null;
  const token = authHeader.replace(/^Bearer\s+/i, '').trim();
  const tokenData = db.verifySessionToken(token);
  if (!tokenData || !tokenData.userId) return null;
  return db.getUserById(tokenData.userId);
}

// Create HTTP Server
const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost:3000'}`);
  const pathname = parsedUrl.pathname;
  const method = req.method.toUpperCase();

  // CORS preflight handling
  if (method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With'
    });
    res.end();
    return;
  }

  // -----------------------------------------------------------------
  // API ROUTING
  // -----------------------------------------------------------------
  if (pathname.startsWith('/api/')) {
    try {
      // 1. AUTHENTICATION ENDPOINTS
      if (pathname === '/api/auth/signup' && method === 'POST') {
        const body = await parseBody(req);
        const { email, password, full_name, role_title, skills_teach, skills_learn } = body;

        if (!email || !password || !full_name) {
          return sendJson(res, 400, { ok: false, error: 'Name, email, and password are required.' });
        }

        const existing = db.getUserByEmail(email);
        if (existing) {
          return sendJson(res, 409, { ok: false, error: 'An account with this email already exists.' });
        }

        const user = db.createUser({
          email,
          password,
          full_name,
          role_title: role_title || 'Skill Swapper',
          skills_teach: skills_teach || '',
          skills_learn: skills_learn || ''
        });

        const token = db.generateSessionToken(user);
        return sendJson(res, 201, { ok: true, user, token, message: 'Account created successfully!' });
      }

      if (pathname === '/api/auth/login' && method === 'POST') {
        const body = await parseBody(req);
        const { email, password } = body;

        if (!email || !password) {
          return sendJson(res, 400, { ok: false, error: 'Invalid email or password. Please try again.' });
        }

        const user = db.getUserByEmail(email);
        if (!user || !user.password_hash || !user.salt) {
          return sendJson(res, 401, { ok: false, error: 'Invalid email or password. Please try again.' });
        }

        const isValid = db.verifyPassword(password, user.password_hash, user.salt);
        if (!isValid) {
          return sendJson(res, 401, { ok: false, error: 'Invalid email or password. Please try again.' });
        }

        const fullUser = db.getUserById(user.id);
        const token = db.generateSessionToken(fullUser);
        return sendJson(res, 200, { ok: true, user: fullUser, token, message: 'Logged in successfully!' });
      }

      if (pathname === '/api/auth/google' && method === 'POST') {
        const body = await parseBody(req);
        const { email, full_name, google_id, avatar_url } = body;

        if (!email) {
          return sendJson(res, 400, { ok: false, error: 'Google email is required.' });
        }

        let user = db.getUserByEmail(email);
        if (!user) {
          // Create new user from Google profile
          user = db.createUser({
            email,
            password: null,
            full_name: full_name || email.split('@')[0],
            role_title: 'Google Swapper',
            avatar_url: avatar_url || '',
            google_id: google_id || `g_${Date.now()}`
          });
        }

        const fullUser = db.getUserById(user.id);
        const token = db.generateSessionToken(fullUser);
        return sendJson(res, 200, { ok: true, user: fullUser, token, message: 'Authenticated with Google!' });
      }

      if (pathname === '/api/auth/me' && method === 'GET') {
        const user = getAuthUser(req);
        if (!user) {
          return sendJson(res, 401, { ok: false, error: 'Unauthorized or session expired.' });
        }
        return sendJson(res, 200, { ok: true, user });
      }

      if (pathname === '/api/auth/logout' && method === 'POST') {
        return sendJson(res, 200, { ok: true, message: 'Logged out successfully.' });
      }

      // 2. USER PROFILE ENDPOINTS
      if (pathname === '/api/users' && method === 'GET') {
        const authUser = getAuthUser(req);
        const users = db.getAllUsers(authUser ? authUser.id : null);
        return sendJson(res, 200, { ok: true, users });
      }

      if (pathname === '/api/users/profile' && method === 'PUT') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        const body = await parseBody(req);
        const updated = db.updateUserProfile(authUser.id, body);
        return sendJson(res, 200, { ok: true, user: updated, message: 'Profile updated successfully!' });
      }

      const userMatch = pathname.match(/^\/api\/users\/(\d+)$/);
      if (userMatch && method === 'GET') {
        const targetId = parseInt(userMatch[1], 10);
        const targetUser = db.getUserById(targetId);
        if (!targetUser) return sendJson(res, 404, { ok: false, error: 'User not found.' });
        return sendJson(res, 200, { ok: true, user: targetUser });
      }

      // 3. MATCHING & DISCOVERY
      if (pathname === '/api/matches' && method === 'GET') {
        const authUser = getAuthUser(req);
        const allUsers = db.getAllUsers(authUser ? authUser.id : null);

        // Filter out current user
        const otherUsers = authUser ? allUsers.filter(u => u.id !== authUser.id) : allUsers;

        // Calculate real match score based on skill overlap
        const matched = otherUsers.map(peer => {
          let score = 50; // base score for registered peer
          let teachMatch = false;
          let learnMatch = false;

          if (authUser && authUser.skills_learn && peer.skills_teach) {
            const myLearns = authUser.skills_learn.toLowerCase().split(/[,·|]/).map(s => s.trim()).filter(Boolean);
            const peerTeaches = peer.skills_teach.toLowerCase().split(/[,·|]/).map(s => s.trim()).filter(Boolean);
            teachMatch = myLearns.some(ml => peerTeaches.some(pt => pt.includes(ml) || ml.includes(pt)));
            if (teachMatch) score += 30;
          }

          if (authUser && authUser.skills_teach && peer.skills_learn) {
            const myTeaches = authUser.skills_teach.toLowerCase().split(/[,·|]/).map(s => s.trim()).filter(Boolean);
            const peerLearns = peer.skills_learn.toLowerCase().split(/[,·|]/).map(s => s.trim()).filter(Boolean);
            learnMatch = myTeaches.some(mt => peerLearns.some(pl => pl.includes(mt) || mt.includes(pl)));
            if (learnMatch) score += 20;
          }

          return {
            ...peer,
            match_score: Math.min(99, score),
            is_reciprocal_match: teachMatch && learnMatch
          };
        }).sort((a, b) => b.match_score - a.match_score);

        return sendJson(res, 200, { ok: true, matches: matched });
      }

      // 4. PROPOSALS & EXCHANGE REQUESTS
      if (pathname === '/api/proposals' && method === 'POST') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Please log in to send a proposal.' });

        const body = await parseBody(req);
        const { receiver_id, learn_skill, teach_skill, message } = body;

        if (!receiver_id || !learn_skill || !teach_skill) {
          return sendJson(res, 400, { ok: false, error: 'Receiver, skill to learn, and skill to teach are required.' });
        }

        if (receiver_id === authUser.id) {
          return sendJson(res, 400, { ok: false, error: 'You cannot send a proposal to yourself.' });
        }

        const proposal = db.createProposal({
          sender_id: authUser.id,
          receiver_id: parseInt(receiver_id, 10),
          learn_skill,
          teach_skill,
          message: message || ''
        });

        return sendJson(res, 201, { ok: true, proposal, message: 'Exchange proposal sent successfully!' });
      }

      if (pathname === '/api/proposals' && method === 'GET') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        const proposals = db.getUserProposals(authUser.id);
        return sendJson(res, 200, { ok: true, proposals });
      }

      const proposalStatusMatch = pathname.match(/^\/api\/proposals\/(\d+)\/status$/);
      if (proposalStatusMatch && method === 'PUT') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        const propId = parseInt(proposalStatusMatch[1], 10);
        const body = await parseBody(req);
        const { status } = body; // 'accepted' or 'rejected'

        if (!['accepted', 'rejected'].includes(status)) {
          return sendJson(res, 400, { ok: false, error: 'Invalid status' });
        }

        const proposal = db.getProposalById(propId);
        if (!proposal) return sendJson(res, 404, { ok: false, error: 'Proposal not found' });

        if (proposal.receiver_id !== authUser.id && proposal.sender_id !== authUser.id) {
          return sendJson(res, 403, { ok: false, error: 'Forbidden' });
        }

        const updated = db.updateProposalStatus(propId, status);
        return sendJson(res, 200, { ok: true, proposal: updated, message: `Proposal ${status}!` });
      }

      // 5. CONVERSATIONS & MESSAGES
      if (pathname === '/api/conversations' && method === 'GET') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        const convs = db.getUserConversations(authUser.id);
        return sendJson(res, 200, { ok: true, conversations: convs });
      }

      const convMessagesMatch = pathname.match(/^\/api\/conversations\/(\d+)\/messages$/);
      if (convMessagesMatch) {
        const convId = parseInt(convMessagesMatch[1], 10);
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        if (method === 'GET') {
          const messages = db.getConversationMessages(convId);
          return sendJson(res, 200, { ok: true, messages });
        }

        if (method === 'POST') {
          const body = await parseBody(req);
          const { text } = body;
          if (!text || !text.trim()) {
            return sendJson(res, 400, { ok: false, error: 'Message text cannot be empty.' });
          }

          const message = db.addMessage({
            conversation_id: convId,
            sender_id: authUser.id,
            text: text.trim()
          });

          return sendJson(res, 201, { ok: true, message });
        }
      }

      const convMeetMatch = pathname.match(/^\/api\/conversations\/(\d+)\/meet$/);
      if (convMeetMatch && method === 'PUT') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        const convId = parseInt(convMeetMatch[1], 10);
        const body = await parseBody(req);
        const { meet_url } = body;

        if (!meet_url || !meet_url.trim()) {
          return sendJson(res, 400, { ok: false, error: 'Valid Google Meet URL required.' });
        }

        const updatedConv = db.updateConversationMeet(convId, meet_url.trim());

        // Broadcast meet link into conversation chat
        db.addMessage({
          conversation_id: convId,
          sender_id: authUser.id,
          text: `📹 Shared Google Meet room: ${meet_url.trim()}`
        });

        return sendJson(res, 200, { ok: true, conversation: updatedConv, message: 'Google Meet link shared!' });
      }

      // 6. REVIEWS & RATINGS
      if (pathname === '/api/reviews' && method === 'GET') {
        const reviews = db.getAllReviews();
        return sendJson(res, 200, { ok: true, reviews });
      }

      if (pathname === '/api/reviews' && method === 'POST') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Please log in to submit a review.' });

        const body = await parseBody(req);
        const { reviewee_id, rating, review_text } = body;

        if (!reviewee_id || !rating || !review_text) {
          return sendJson(res, 400, { ok: false, error: 'Reviewee, rating (1-5), and review text are required.' });
        }

        const numericRating = parseInt(rating, 10);
        if (numericRating < 1 || numericRating > 5) {
          return sendJson(res, 400, { ok: false, error: 'Rating must be between 1 and 5 stars.' });
        }

        if (parseInt(reviewee_id, 10) === authUser.id) {
          return sendJson(res, 400, { ok: false, error: 'You cannot review yourself.' });
        }

        const review = db.addReview({
          reviewer_id: authUser.id,
          reviewee_id: parseInt(reviewee_id, 10),
          rating: numericRating,
          review_text: review_text.trim()
        });

        return sendJson(res, 201, { ok: true, review, message: 'Review & rating submitted successfully!' });
      }

      // 7. SESSIONS
      if (pathname === '/api/sessions' && method === 'GET') {
        const authUser = getAuthUser(req);
        if (!authUser) return sendJson(res, 401, { ok: false, error: 'Unauthorized' });

        const sessions = db.getUserSessions(authUser.id);
        return sendJson(res, 200, { ok: true, sessions });
      }

      // 8. PLATFORM STATS
      if (pathname === '/api/stats' && method === 'GET') {
        const stats = db.getPlatformStats();
        return sendJson(res, 200, { ok: true, stats });
      }

      // 9. DATABASE SEED UTILITY (For quick testing/demo)
      if (pathname === '/api/seed' && method === 'POST') {
        const userCount = db.getPlatformStats().total_users;
        if (userCount === 0) {
          // Create initial seed users with skills & realistic interactions
          const u1 = db.createUser({
            email: 'sadia@skillswap.io',
            password: 'password123',
            full_name: 'Sadia Ahmed Mim',
            role_title: 'Lead UI/UX Designer',
            avatar_url: 'mim.jpg',
            skills_teach: 'Figma, Design Systems, UI/UX Design',
            skills_learn: 'React, 3D Web, Next.js',
            project_interest: '3D Interactive Brand Guidelines',
            cadence: 'Weekly Google Meet Sessions'
          });

          const u2 = db.createUser({
            email: 'khaled@skillswap.io',
            password: 'password123',
            full_name: 'Khaled Saifullah',
            role_title: 'Full-Stack Engineer & Storyteller',
            avatar_url: 'saif.jpg',
            skills_teach: 'React, Node.js, Photography, UX writing',
            skills_learn: 'Cloud DevOps, Brand strategy',
            project_interest: 'Open-Source Photography CMS',
            cadence: '2 sessions/week · 45 mins each'
          });

          const u3 = db.createUser({
            email: 'shoptorshi@skillswap.io',
            password: 'password123',
            full_name: 'Shoptorshi Chumky',
            role_title: 'Software Engineer & Tech Speaker',
            avatar_url: 'shoptoshi.jpg',
            skills_teach: 'Python, Public speaking, Presentation',
            skills_learn: 'English fluency, Machine Learning',
            project_interest: 'AI Speech Clarity Evaluator',
            cadence: 'Flexible / Weekend sprints'
          });

          const u4 = db.createUser({
            email: 'miraz@skillswap.io',
            password: 'password123',
            full_name: 'Miraz Montasir',
            role_title: 'Brand Strategist & Creative Director',
            avatar_url: 'miraz.jpg',
            skills_teach: 'Brand strategy, Motion design, HTML',
            skills_learn: 'Full-Stack Development, Python',
            project_interest: 'Interactive 3D Brand Storytelling',
            cadence: 'Weekly Google Meet Sessions'
          });

          // Add real reciprocal reviews in database
          db.addReview({
            reviewer_id: u3.id,
            reviewee_id: u4.id,
            rating: 5,
            review_text: 'I signed up for a single Python session and gained a brilliant mentor and collaborator.'
          });

          db.addReview({
            reviewer_id: u2.id,
            reviewee_id: u1.id,
            rating: 5,
            review_text: 'The swap was effortless from the very first greeting. We both walked away with tangible skills.'
          });

          // Create conversation between u1 & u2
          const conv = db.getOrCreateConversation(u1.id, u2.id);
          db.addMessage({
            conversation_id: conv.id,
            sender_id: u1.id,
            text: 'I added the Figma case studies to our shared session board! Looking forward to reviewing motion graphics ideas with you.'
          });
          db.addMessage({
            conversation_id: conv.id,
            sender_id: u2.id,
            text: 'Awesome! I prepared a few dynamic transition concepts. See you on Friday!'
          });

          return sendJson(res, 200, { ok: true, message: 'Database initialized with initial peers.' });
        }
        return sendJson(res, 200, { ok: true, message: 'Database already contains users.' });
      }

      // If no API route matched:
      return sendJson(res, 404, { ok: false, error: `API route ${method} ${pathname} not found.` });

    } catch (err) {
      console.error('API Error:', err);
      return sendJson(res, 500, { ok: false, error: err.message || 'Internal Server Error' });
    }
  }

  // -----------------------------------------------------------------
  // STATIC ASSET SERVING
  // -----------------------------------------------------------------
  let filePath = path.join(PUBLIC_DIR, pathname === '/' ? 'index.html' : pathname);

  // Security check: prevent directory traversal
  const normalizedPath = path.normalize(filePath);
  if (!normalizedPath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403, { 'Content-Type': 'text/plain' });
    res.end('403 Forbidden');
    return;
  }

  fs.stat(normalizedPath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html if not found
      filePath = path.join(PUBLIC_DIR, 'index.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end('404 Not Found');
        return;
      }

      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': 'no-cache'
      });
      res.end(content);
    });
  });
});

server.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`🚀 SkillSwap Dynamic Server is running!`);
  console.log(`🌐 URL: http://localhost:${PORT}`);
  console.log(`📦 Database: SQLite (node:sqlite) initialized`);
  console.log(`====================================================`);
});

module.exports = server;


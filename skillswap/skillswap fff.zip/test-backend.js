/**
 * SkillSwap Backend Integration & Verification Tests
 */

const assert = require('node:assert');
const db = require('./database');

console.log('🧪 Starting SkillSwap Backend & Database Tests...\n');

async function runTests() {
  try {
    // 1. Test User Registration
    console.log('1. Testing User Registration...');
    const testEmail = `tester_${Date.now()}@skillswap.io`;
    const userA = db.createUser({
      email: testEmail,
      password: 'SecurePassword123!',
      full_name: 'Test Engineer',
      role_title: 'Full Stack Dev',
      skills_teach: 'Node.js, SQLite, React',
      skills_learn: 'UI/UX Design, Figma',
      project_interest: 'Building SkillSwap backend'
    });

    assert.ok(userA.id, 'User ID should be generated');
    assert.strictEqual(userA.email, testEmail.toLowerCase());
    console.log('   ✓ User registered successfully: ID', userA.id);

    // 2. Test Password Verification
    console.log('2. Testing Password Verification...');
    const userFromDb = db.getUserByEmail(testEmail);
    const validPass = db.verifyPassword('SecurePassword123!', userFromDb.password_hash, userFromDb.salt);
    const invalidPass = db.verifyPassword('WrongPass', userFromDb.password_hash, userFromDb.salt);
    assert.strictEqual(validPass, true, 'Valid password should verify');
    assert.strictEqual(invalidPass, false, 'Invalid password should fail');
    console.log('   ✓ Password hashing & verification work as expected');

    // 3. Test Session Token
    console.log('3. Testing JWT Session Token generation & verification...');
    const token = db.generateSessionToken(userA);
    const decoded = db.verifySessionToken(token);
    assert.ok(decoded, 'Token should decode successfully');
    assert.strictEqual(decoded.userId, userA.id);
    console.log('   ✓ Session token created and validated');

    // 4. Test Second User & Profile Update
    console.log('4. Testing Second User & Profile Update...');
    const userB = db.createUser({
      email: `designer_${Date.now()}@skillswap.io`,
      password: 'password123',
      full_name: 'Alex Design',
      role_title: 'UI Designer',
      skills_teach: 'Figma, UI/UX Design, CSS',
      skills_learn: 'Node.js, React'
    });

    const updatedUserA = db.updateUserProfile(userA.id, {
      bio: 'Lifelong learner building awesome tools.'
    });
    assert.strictEqual(updatedUserA.bio, 'Lifelong learner building awesome tools.');
    console.log('   ✓ Second user created & profile update persisted');

    // 5. Test Exchange Proposal
    console.log('5. Testing Exchange Proposal Flow...');
    const proposal = db.createProposal({
      sender_id: userA.id,
      receiver_id: userB.id,
      learn_skill: 'Figma',
      teach_skill: 'Node.js',
      message: 'Would love to trade Figma lessons for Node.js backend coaching!'
    });
    assert.ok(proposal.id, 'Proposal should be created');
    assert.strictEqual(proposal.status, 'pending');

    const acceptedProposal = db.updateProposalStatus(proposal.id, 'accepted');
    assert.strictEqual(acceptedProposal.status, 'accepted');
    console.log('   ✓ Proposal sent and accepted');

    // 6. Test Conversations & Real Messages
    console.log('6. Testing Real Conversations & Messages...');
    const convs = db.getUserConversations(userA.id);
    assert.ok(convs.length > 0, 'User should have at least 1 conversation');
    const convId = convs[0].id;

    const msg = db.addMessage({
      conversation_id: convId,
      sender_id: userA.id,
      text: 'Hey Alex! Ready for our first exchange.'
    });
    assert.ok(msg.id, 'Message should be saved');

    const chatHistory = db.getConversationMessages(convId);
    assert.ok(chatHistory.length >= 2, 'Chat history should contain initial greeting and new message');
    console.log(`   ✓ Conversation messages retrieved: ${chatHistory.length} messages found`);

    // 7. Test Google Meet Link Integration
    console.log('7. Testing Google Meet Session Link Update...');
    const newMeet = 'https://meet.google.com/abc-defg-hij';
    const updatedConv = db.updateConversationMeet(convId, newMeet);
    assert.strictEqual(updatedConv.meet_url, newMeet);
    console.log('   ✓ Google Meet URL updated successfully');

    // 8. Test Dynamic Ratings & Reviews
    console.log('8. Testing Real Rating & Review Submission...');
    const review = db.addReview({
      reviewer_id: userA.id,
      reviewee_id: userB.id,
      rating: 5,
      review_text: 'Alex was an incredible design mentor! Highly recommended.'
    });
    assert.ok(review.id, 'Review should be recorded');

    const userBWithRating = db.getUserById(userB.id);
    assert.strictEqual(userBWithRating.avg_rating, 5);
    assert.strictEqual(userBWithRating.review_count, 1);
    console.log(`   ✓ Real rating calculated dynamically: ${userBWithRating.avg_rating}★ (${userBWithRating.review_count} review)`);

    // 9. Test Platform Stats
    console.log('9. Testing Platform Dynamic Stats...');
    const stats = db.getPlatformStats();
    assert.ok(stats.total_users >= 2, 'Total users should match DB count');
    assert.ok(stats.total_reviews >= 1, 'Total reviews should match DB count');
    console.log('   ✓ Platform stats:', JSON.stringify(stats));

    console.log('\n🎉 ALL BACKEND & DATABASE TESTS PASSED SUCCESSFULLY!');
  } catch (err) {
    console.error('\n❌ Test Failure:', err);
    process.exit(1);
  }
}

runTests();
